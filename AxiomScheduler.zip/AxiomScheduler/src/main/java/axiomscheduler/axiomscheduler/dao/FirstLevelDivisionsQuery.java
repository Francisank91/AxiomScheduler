package axiomscheduler.axiomscheduler.dao;

import axiomscheduler.axiomscheduler.model.Customer;
import axiomscheduler.axiomscheduler.model.Divisions;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FirstLevelDivisionsQuery {


    /**
     * Returns list of all Divisions.
     * @return
     */
    public static ObservableList<Divisions> getAllDivisions(){
        ObservableList<Divisions> divisionList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT DISTINCT Division_ID, Division, Country_ID FROM client_schedule.first_level_divisions";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                int divisionId = rs.getInt("Division_ID");
                String division = rs.getString("Division");
                int  countryId =  rs.getInt("Country_ID");


                Divisions d = new Divisions(division,divisionId,countryId);

                divisionList.add(d);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return divisionList;
    }


    /**
     * Returns list of distinct Divisions.
     * @return
     */
    public static ObservableList<Divisions> getAllDistinctDivisions(){
        ObservableList<Divisions> divisionList = FXCollections.observableArrayList();
        //Finish creating division lists
        try {
            String sql = "SELECT DISTINCT Division_ID, DISTINCT Division, DISTINCT Country_ID FROM client_schedule.first_level_divisions";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                int divisionId = rs.getInt("Division_ID");
                String division = rs.getString("Division");
                int  countryId =  rs.getInt("Country_ID");


                Divisions d = new Divisions(division,divisionId,countryId);

                divisionList.add(d);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return divisionList;
    }


    /**
     * Returns Division ID from Division Name.
     * @param divisionName
     * @return
     * @throws SQLException
     */
    public static int divisionNameToId(String divisionName) throws SQLException {
        String sql = "SELECT * FROM first_level_divisions WHERE Division = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1, divisionName);
        ResultSet rs = ps.executeQuery();
        int divisionId = 0;
        while (rs.next()) {


            divisionId = rs.getInt("Division_ID");

        }
        System.out.println(divisionId);
        return divisionId;
    }


    /**
     * Returns Division name when provided Division ID
     * @param divisionId
     * @return
     * @throws SQLException
     */
    public static String divisionIdToName(int divisionId) throws SQLException {
        String sql = "SELECT * FROM first_level_divisions WHERE Division_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, divisionId);
        ResultSet rs = ps.executeQuery();
        String divisionName = "null";
        while (rs.next()) {

            divisionName = rs.getString("Division");

        }
        return divisionName;
    }













}
