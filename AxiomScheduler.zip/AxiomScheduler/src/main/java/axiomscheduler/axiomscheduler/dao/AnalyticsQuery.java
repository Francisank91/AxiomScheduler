package axiomscheduler.axiomscheduler.dao;

import axiomscheduler.axiomscheduler.helper.utilities;
import axiomscheduler.axiomscheduler.model.Appointment;
import axiomscheduler.axiomscheduler.model.Reporting;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class AnalyticsQuery {


    /**
     * Returns all appointments from database for Reporting.
     * @return
     */
    public static ObservableList<Appointment> getAllAppointments(){
        ObservableList<Appointment> appList = FXCollections.observableArrayList();

        try {

            String sql = "SELECT appointments.Appointment_ID, Title, Description, Location, contacts.Contact_Name, Type, Start, End, appointments.Customer_ID, appointments.User_ID FROM client_schedule.appointments, client_schedule.users, client_schedule.contacts, client_schedule.customers WHERE appointments.User_ID = users.User_ID AND appointments.Customer_ID = customers.Customer_ID AND appointments.Contact_ID = contacts.Contact_ID ORDER BY appointments.Customer_ID";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                int appointmentId = rs.getInt("Appointment_ID");
                String appointmentTitle = rs.getString("Title");
                String appointmentDescription = rs.getString("Description");
                String appointmentLocation= rs.getString("Location");
                String appointmentContact= rs.getString("Contact_Name");
                String appointmentType= rs.getString("Type");
                LocalDateTime appointmentStartDt = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime appointmentEndDt = rs.getTimestamp("End").toLocalDateTime();
                int appointmentCustomerId = rs.getInt("Customer_ID");
                int appointmentUserId = rs.getInt("User_ID");

                Appointment a = new Appointment(appointmentId, appointmentTitle, appointmentDescription, appointmentLocation,appointmentContact, appointmentType, appointmentStartDt, appointmentEndDt, appointmentCustomerId, appointmentUserId);

                appList.add(a);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return appList;
    }


    /**
     * Returns Total Appointments Report.
     * @return
     */
    public static ObservableList<Reporting> totalAppointmentsReport(){
        ObservableList<Reporting> totalAppointmentsReport = FXCollections.observableArrayList();

        try {

            String sql = "SELECT monthname(start) AS Month, COUNT(Appointment_ID) AS AppointmentCount, Type FROM client_schedule.appointments GROUP BY monthname(Start), Type ORDER BY Month, AppointmentCount ASC;";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){

                String taMonth= rs.getString("Month");
                String taType= rs.getString("Type");
                int totalAppointments = rs.getInt("AppointmentCount");

                Reporting ta = new Reporting(totalAppointments,taMonth,taType);

                totalAppointmentsReport.add(ta);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return totalAppointmentsReport;
    }


    /**
     * Returns Total Appointment Time Report.
     * @return
     */
    public static ObservableList<Reporting> totalAppointmentsTimeReport(){
        ObservableList<Reporting> totalAppointmentTimeReport = FXCollections.observableArrayList();

        try {

            String sql = "SELECT a.Customer_ID, c.Customer_Name, SUM(TIMESTAMPDIFF(MINUTE, a.Start, a.End)) AS total_MinuteTime FROM client_schedule.appointments a INNER JOIN client_schedule.customers c ON a.Customer_ID = c.Customer_ID GROUP BY a.Customer_ID, c.Customer_Name;";

            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){

                int tapCustomerId = rs.getInt("Customer_ID");
                String tapCustomerName= rs.getString("Customer_Name");
                int tapTotalAppointmentTime = rs.getInt("total_MinuteTime");


                Reporting tat = new Reporting(tapCustomerId,tapCustomerName,tapTotalAppointmentTime);

                totalAppointmentTimeReport.add(tat);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return totalAppointmentTimeReport;
    }


    /**
     * Returns Total Customers Report.
     * @return
     */
    public static ObservableList<Reporting> totalCustomersReport(){
        ObservableList<Reporting> totalCustomersReport = FXCollections.observableArrayList();

        try {

            String sql = "SELECT Country, Customer_ID FROM client_schedule.customers INNER JOIN client_schedule.first_level_divisions ON customers.Division_ID = first_level_divisions.Division_ID INNER JOIN client_schedule.countries ON first_level_divisions.Country_ID = countries.Country_ID;";

            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){

                String tcCountry= rs.getString("Country");
                int totalCustomers = rs.getInt("Customer_ID");

                Reporting tc = new Reporting(totalCustomers,tcCountry);

                totalCustomersReport.add(tc);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return totalCustomersReport;
    }




}
