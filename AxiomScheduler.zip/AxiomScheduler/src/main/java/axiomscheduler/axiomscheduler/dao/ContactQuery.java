package axiomscheduler.axiomscheduler.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class ContactQuery {


    /**
     * Returns contacts inserted to table.
     * @param contactName
     * @param contactId
     * @return
     * @throws SQLException
     */
    public static int insert(String contactName, int contactId) throws SQLException {
        String sql = "INSERT INTO contacts (Contact_Name, Contact_ID) VALUES(?,?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1,contactName);
        ps.setInt(2,contactId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * Returns contacts updated to table.
     * @param contactEmail
     * @param contactId
     * @return
     * @throws SQLException
     */
    public static int update(String contactEmail, int contactId) throws SQLException {
        String sql = "UPDATE contacts SET Email = ? WHERE Contact_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1,contactEmail);
        ps.setInt(2,contactId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * Deletes contacts from contacts table.
     * @param contactId
     * @return
     * @throws SQLException
     */
    public static int delete(int contactId) throws SQLException {
        String sql = "DELETE FROM contacts WHERE Contact_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1,contactId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * Selects all rows from contacts.
     * @throws SQLException
     */
    public static void select() throws SQLException {
        String sql = "SELECT * FROM contacts";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int contactId = rs.getInt("Contact_ID");
            String contactName = rs.getString("Contact_Name");
            System.out.print(contactId + " | ");
            System.out.print(contactName + "\n");
        }
    }


    /**
     * Selects all rows from contacts with defined email.
     * @param contactEmail
     * @throws SQLException
     */
    public static void select(String contactEmail) throws SQLException {
        String sql = "SELECT * FROM contacts WHERE Email = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1, contactEmail);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int contactId = rs.getInt("Contact_ID");
            String contactName = rs.getString("Contact_Name");
            String contactEmailID = rs.getString("Email");
            System.out.print(contactId + " | ");
            System.out.print(contactName + " | ");
            System.out.print(contactEmailID + "\n");
        }
    }

    /**
     * Selects all Contacts from table.
     * @throws SQLException
     */
    public static void selectAllContacts() throws SQLException {
        String sql = "SELECT * FROM contacts";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while(rs.next()){

            String contactName = rs.getString("Contact_Name");

        }
    }

    /**
     * Returns Contact ID from Contact Name.
     * @param contactName
     * @return
     * @throws SQLException
     */
    public static int contactNameToId(String contactName) throws SQLException {
        String sql = "SELECT * FROM contacts WHERE Contact_Name = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1, contactName);
        ResultSet rs = ps.executeQuery();
        int contactId = 0;
        while (rs.next()) {


            contactId = rs.getInt("Contact_ID");
            String contactSQLName = rs.getString("Contact_Name");

        }
        return contactId;
    }








































}
