package axiomscheduler.axiomscheduler.dao;

import axiomscheduler.axiomscheduler.model.Customer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDateTime;

public abstract class CustomerQuery {

    /**
     * Returns list of all Customers.
     * @return
     */
    public static ObservableList<Customer> getAllCustomers(){
        ObservableList<Customer> custList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT Customer_ID, Customer_Name, Address, first_level_divisions.Division, Postal_Code, Phone, countries.Country FROM client_schedule.customers, client_schedule.first_level_divisions, client_schedule.countries WHERE customers.Division_ID = first_level_divisions.Division_ID AND countries.Country_ID = first_level_divisions.Country_ID";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                int customerId = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String customerAddress = rs.getString("Address");
                String customerStateTerritory = rs.getString("Division");
                String customerPostalCode = rs.getString("Postal_Code");
                String customerPhone = rs.getString("Phone");
                String customerCountry = rs.getString("Country");

                Customer c = new Customer(customerId, customerName, customerAddress, customerStateTerritory, customerPostalCode, customerPhone,customerCountry);

                custList.add(c);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return custList;
    }


    /**
     * Returns inserted row from customer table.
     * @param customerName
     * @param customerId
     * @return
     * @throws SQLException
     */
    public static int insert(String customerName, int customerId) throws SQLException {
        String sql = "INSERT INTO customers (Customer_Name, Customer_ID) VALUES(?,?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1,customerName);
        ps.setInt(2,customerId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * Adds Customer into database.
     * @param customerName
     * @param customerAddress
     * @param customerPhoneNumber
     * @param customerPostalCode
     * @param divisionId
     * @throws SQLException
     */
    public static void addCustomer(String customerName, String customerAddress, String customerPhoneNumber, String customerPostalCode, int divisionId) throws SQLException {
        // String sql = "INSERT INTO client_schedule.appointments (Null, Title, Description, Location, Type, Start, End, appointments.Customer_ID, appointments.User_ID FROM client_schedule.appointments, client_schedule.contacts, client_schedule.customers, client_schedule.first_level_divisions) VALUES(?,?,?,?,?,?,?,?,?)";
        String sql = "INSERT INTO client_schedule.customers (Customer_Name, Address, Phone, Postal_Code, Division_ID) VALUES (?, ?, ?, ?, ?)";

        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setString(1,customerName);
        ps.setString(2,customerAddress);
        ps.setString(3,customerPhoneNumber);
        ps.setString(4,customerPostalCode);
        ps.setInt(5, divisionId);



        ps.execute();
        //Retrieve generated keys for customerID to insert into next table
        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        int customerId = rs.getInt(1);


    }


    /**
     * Updates row in Customer table.
     * @param customerName
     * @param customerAddress
     * @param customerPhoneNumber
     * @param customerPostalCode
     * @param divisionId
     * @param customerId
     * @return
     * @throws SQLException
     */
    public static int updateCustomer(String customerName, String customerAddress, String customerPhoneNumber, String customerPostalCode, int divisionId,int customerId) throws SQLException {
        String sql = "UPDATE customers SET Customer_Name = ?, Address = ?, Phone = ?, Postal_Code = ?, Division_ID = ? WHERE Customer_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1,customerName);
        ps.setString(2,customerAddress);
        ps.setString(3,customerPhoneNumber);
        ps.setString(4,customerPostalCode);
        ps.setInt(5,divisionId);
        ps.setInt(6,customerId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**
     * Deletes customer from database.
     * @param customerId
     * @return
     * @throws SQLException
     */
    public static int deleteCustomer(int customerId) throws SQLException {
        String sql = "DELETE FROM customers WHERE Customer_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1,customerId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }


































}
