package axiomscheduler.axiomscheduler.dao;

import axiomscheduler.axiomscheduler.helper.utilities;
import axiomscheduler.axiomscheduler.model.Appointment;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.scene.control.ChoiceBox;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class AppointmentQuery {

    /**
     * Returns list of all appointments from the database for the Appointment table view.
     */
    public static ObservableList<Appointment> getAllAppointments(){
        ObservableList<Appointment> appList = FXCollections.observableArrayList();

        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd h:mm a");
            String sql ="SELECT appointments.Appointment_ID, Title, Description, Location, contacts.Contact_Name, Type, Start, End, appointments.Customer_ID, appointments.User_ID  FROM client_schedule.appointments INNER JOIN client_schedule.users ON appointments.User_ID = users.User_ID INNER JOIN client_schedule.contacts ON appointments.Contact_ID = contacts.Contact_ID INNER JOIN client_schedule.customers ON appointments.Customer_ID = customers.Customer_ID";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                int appointmentId = rs.getInt("Appointment_ID");
                String appointmentTitle = rs.getString("Title");
                String appointmentDescription = rs.getString("Description");
                String appointmentLocation= rs.getString("Location");
                String appointmentContact= rs.getString("Contact_Name");
                String appointmentType= rs.getString("Type");
                LocalDateTime appointmentStartDt = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime appointmentEndDt = rs.getTimestamp("End").toLocalDateTime();
                int appointmentCustomerId = rs.getInt("Customer_ID");
                int appointmentUserId = rs.getInt("User_ID");

                Appointment a = new Appointment(appointmentId, appointmentTitle, appointmentDescription, appointmentLocation,appointmentContact, appointmentType, appointmentStartDt, appointmentEndDt, appointmentCustomerId, appointmentUserId);

                appList.add(a);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return appList;
    }

    /**
     * Returns appointments by current month from database.
     * @return
     */
    public static ObservableList<Appointment> getAppointmentsByMonth(){
        ObservableList<Appointment> appList = FXCollections.observableArrayList();

        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd h:mm a");
            String sql = "SELECT appointments.Appointment_ID, Title, Description, Location, contacts.Contact_Name, Type, Start, End, appointments.Customer_ID, appointments.User_ID FROM client_schedule.appointments INNER JOIN client_schedule.users ON appointments.User_ID = users.User_ID INNER JOIN client_schedule.customers ON appointments.Customer_ID = customers.Customer_ID INNER JOIN client_schedule.contacts ON appointments.Contact_ID = contacts.Contact_ID WHERE EXTRACT(YEAR_MONTH FROM appointments.Start) = EXTRACT(YEAR_MONTH FROM NOW())";

            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                int appointmentId = rs.getInt("Appointment_ID");
                String appointmentTitle = rs.getString("Title");
                String appointmentDescription = rs.getString("Description");
                String appointmentLocation= rs.getString("Location");
                String appointmentContact= rs.getString("Contact_Name");
                String appointmentType= rs.getString("Type");
                LocalDateTime appointmentStartDt = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime appointmentEndDt = rs.getTimestamp("End").toLocalDateTime();
                int appointmentCustomerId = rs.getInt("Customer_ID");
                int appointmentUserId = rs.getInt("User_ID");

                Appointment a = new Appointment(appointmentId, appointmentTitle, appointmentDescription, appointmentLocation,appointmentContact, appointmentType, appointmentStartDt, appointmentEndDt, appointmentCustomerId, appointmentUserId);

                appList.add(a);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return appList;
    }

    /**
     * Returns appointments by current week from database.
     * @return
     */
    public static ObservableList<Appointment> getAppointmentsByWeek(){
        ObservableList<Appointment> appList = FXCollections.observableArrayList();

        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd h:mm a");
            String sql = "SELECT appointments.Appointment_ID, Title, Description, Location, contacts.Contact_Name, Type, Start, End, appointments.Customer_ID, appointments.User_ID FROM client_schedule.appointments INNER JOIN client_schedule.users ON appointments.User_ID = users.User_ID INNER JOIN client_schedule.customers ON appointments.Customer_ID = customers.Customer_ID INNER JOIN client_schedule.contacts ON appointments.Contact_ID = contacts.Contact_ID WHERE EXTRACT(YEAR FROM appointments.Start) = EXTRACT(YEAR FROM NOW()) AND EXTRACT(WEEK FROM appointments.Start) = EXTRACT(WEEK FROM NOW())";

            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                int appointmentId = rs.getInt("Appointment_ID");
                String appointmentTitle = rs.getString("Title");
                String appointmentDescription = rs.getString("Description");
                String appointmentLocation= rs.getString("Location");
                String appointmentContact= rs.getString("Contact_Name");
                String appointmentType= rs.getString("Type");
                LocalDateTime appointmentStartDt = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime appointmentEndDt = rs.getTimestamp("End").toLocalDateTime();
                int appointmentCustomerId = rs.getInt("Customer_ID");
                int appointmentUserId = rs.getInt("User_ID");

                Appointment a = new Appointment(appointmentId, appointmentTitle, appointmentDescription, appointmentLocation,appointmentContact, appointmentType, appointmentStartDt, appointmentEndDt, appointmentCustomerId, appointmentUserId);

                appList.add(a);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return appList;
    }


    /**
     * Adds appointment to the database.
     * @param appointmentTitle
     * @param appointmentDescription
     * @param appointmentLocation
     * @param appointmentType
     * @param appointmentStartDt
     * @param appointmentEndDt
     * @param appointmentCustomerId
     * @param appointmentUserId
     * @param appointmentContactId
     * @throws SQLException
     */
    public static void addAppointment(String appointmentTitle, String appointmentDescription, String appointmentLocation, String appointmentType, LocalDateTime appointmentStartDt, LocalDateTime appointmentEndDt, int appointmentCustomerId, int  appointmentUserId, int appointmentContactId) throws SQLException {
       // String sql = "INSERT INTO client_schedule.appointments (Null, Title, Description, Location, Type, Start, End, appointments.Customer_ID, appointments.User_ID FROM client_schedule.appointments, client_schedule.contacts, client_schedule.customers, client_schedule.first_level_divisions) VALUES(?,?,?,?,?,?,?,?,?)";
        String sql = "INSERT INTO client_schedule.appointments (Title, Description, Location, Type, Start, End, Customer_ID, User_ID, Contact_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";//Add ContactID

        PreparedStatement ps = JDBC.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setString(1,appointmentTitle);
        ps.setString(2,appointmentDescription);
        ps.setString(3, appointmentLocation);
        ps.setString(4,appointmentType);
        ps.setTimestamp(5, Timestamp.valueOf(appointmentStartDt));//TS value of ZDT
        ps.setTimestamp(6, Timestamp.valueOf(appointmentEndDt));
        ps.setInt(7,appointmentCustomerId);
        ps.setInt(8,appointmentUserId);
        ps.setInt(9, appointmentContactId);
        ps.execute();
        //Retrieve generated keys for appointmentID to insert into next table
        ResultSet rs = ps.getGeneratedKeys();
        rs.next();
        int appointmentId = rs.getInt(1);


    }

    /**
     * Updates selected appointment from the database.
     * @param appointmentId
     * @param appointmentTitle
     * @param appointmentDescription
     * @param appointmentLocation
     * @param appointmentType
     * @param appointmentStartDt
     * @param appointmentEndDt
     * @param appointmentCustomerId
     * @param appointmentUserId
     * @param appointmentContactId
     * @return
     * @throws SQLException
     */
    public static int updateAppointment(int appointmentId, String appointmentTitle, String appointmentDescription, String appointmentLocation, String appointmentType, LocalDateTime appointmentStartDt, LocalDateTime appointmentEndDt, int appointmentCustomerId, int  appointmentUserId, int appointmentContactId) throws SQLException {
        String sql = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1,appointmentTitle);
        ps.setString(2,appointmentDescription);
        ps.setString(3, appointmentLocation);
        ps.setString(4,appointmentType);
        ps.setTimestamp(5, Timestamp.valueOf(appointmentStartDt));//TS value of ZDT
        ps.setTimestamp(6, Timestamp.valueOf(appointmentEndDt));
        ps.setInt(7,appointmentCustomerId);
        ps.setInt(8,appointmentUserId);
        ps.setInt(9, appointmentContactId);
        ps.setInt(10,appointmentId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;

    }

    /**
     * Deletes selected appointment from the database.
     * @param appointmentId
     * @return
     * @throws SQLException
     */
    public static int deleteAppointment(int appointmentId) throws SQLException {
        String sql = "DELETE FROM appointments WHERE Appointment_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1,appointmentId);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }


    /**
     * Delivers fifteen minute appointment alerts to user upon login by the LAMBDA expression "i->true" to construct a filtered list of appointments.
     * @throws SQLException
     */
    public static void appointmentAlert() throws SQLException {
        LocalTime currentTime = LocalDateTime.now().toLocalTime();
        FilteredList<Appointment> filteredAppointmentList = new FilteredList<>(AppointmentQuery.getAllAppointments(), i-> true);
        boolean upcomingAppointment = false;
        //ArrayList<Appointment> allAppointmentsList = new ArrayList<>();
        for( Appointment i :  filteredAppointmentList){
            long appointmentInFifteen = ChronoUnit.MINUTES.between(currentTime,i.getAppointmentStartDt());
            if( appointmentInFifteen > 0 && appointmentInFifteen <= 15) {
                System.out.println("you have an appointment within " + appointmentInFifteen + " minute(s)");
                upcomingAppointment = true;
                utilities.systemAlertNotice("Notice", "Appointment: " + i.getAppointmentId() + " set for, " + i.getAppointmentStartDt() + " will start within 15 minutes.");
            }
//            System.out.println("Current Time: " + currentTime);
//            System.out.println("Time Difference: " + appointmentInFifteen);
//            System.out.println("Get app Start Date: " + i.getAppointmentStartDt());

        }
        if(upcomingAppointment == false) {
            utilities.systemAlertNotice("Notice", "you have an no upcoming appointments");
            System.out.println("you have an no upcoming appointments");
        }
    }





}
