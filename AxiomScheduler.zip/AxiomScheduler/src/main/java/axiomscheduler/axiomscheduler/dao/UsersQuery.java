package axiomscheduler.axiomscheduler.dao;

import axiomscheduler.axiomscheduler.model.Customer;
import axiomscheduler.axiomscheduler.model.Users;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsersQuery {


    /**
     * Returns list of users from the database.
     * @return
     */
    public static ObservableList<Users> getAllUsers(){
        ObservableList<Users> userList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT User_ID, User_Name FROM client_schedule.users ORDER BY User_ID ASC";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                int userId = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");


                Users u = new Users(userId, userName);

                userList.add(u);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return userList;
    }



    /**
     * Validates username and password for application login
     * @param userName
     * @param password
     * @return
     * @throws SQLException
     */
    public static String loginForm(String userName, String password) throws SQLException {
        String sql = "SELECT * FROM users Where User_Name = ? AND Password = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1, userName);
        ps.setString(2, password);
        ResultSet rs = ps.executeQuery();
        String dv = "false";
        while (rs.next()) {
            String user = rs.getString("User_Name");//retrieve data from result set
            String pass = rs.getString("Password");
            //potential lambda equals upgrade
            if (userName.equals(user)) {
                if (password.equals(pass)) {
                    dv = "true";
                } else {
                    dv = "false";
                }
            } else {
                dv = "false";
            }
        }
        return dv;
    }

    /**
     * Returns User_ID when provided username
     * @param userName
     * @return
     * @throws SQLException
     */
    public static int userNameToId(String userName) throws SQLException {
        String sql = "SELECT * FROM users WHERE User_Name = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1, userName);
        ResultSet rs = ps.executeQuery();
        int userId = 0;
        while (rs.next()) {


            userId = rs.getInt("User_ID");
            String contactSQLName = rs.getString("User_Name");


//            if (contactName == contactSQLName){
//                return ;
//            }
        }
        return userId;
    }










}