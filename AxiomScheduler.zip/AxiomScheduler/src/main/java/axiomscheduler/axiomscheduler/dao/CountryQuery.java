package axiomscheduler.axiomscheduler.dao;

import axiomscheduler.axiomscheduler.model.Countries;
import axiomscheduler.axiomscheduler.model.Divisions;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CountryQuery {


    /**
     * Returns list of all Countries
     * @return
     */
    public static ObservableList<Countries> getAllCountries(){
        ObservableList<Countries> countryList = FXCollections.observableArrayList();
        //Finish creating division lists
        try {
            String sql = "SELECT DISTINCT Country_ID, Country FROM client_schedule.countries";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                int countryId = rs.getInt("Country_ID");
                String countryName = rs.getString("Country");



                Countries c = new Countries(countryId, countryName);

                countryList.add(c);

            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        return countryList;
    }


    /**
     * Returns Country ID from Country Name.
     * @param countryName
     * @return
     * @throws SQLException
     */
    public static int countryNameToId(String countryName) throws SQLException {
        String sql = "SELECT * FROM countries WHERE Country = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1, countryName);
        ResultSet rs = ps.executeQuery();
        int countryId = 0;
        while (rs.next()) {


            countryId = rs.getInt("Country_ID");

        }
        return countryId;
    }

    /**
     * Returns Country Name from Country ID.
     * @param countryId
     * @return
     * @throws SQLException
     */
    public static String countryIdToName(int countryId) throws SQLException {
        String sql = "SELECT * FROM countries WHERE Country_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, countryId);
        ResultSet rs = ps.executeQuery();
        String countryName = "null";
        while (rs.next()) {

            countryName = rs.getString("Country");

        }
        return countryName;
    }




}
