package axiomscheduler.axiomscheduler.helper;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
import java.util.Optional;

public class utilities {
    /**
     * Returns Location Date Time concatenation.
     * @param utcDate
     * @param utcTime
     * @return
     */
    public static LocalDateTime TimeZone(LocalDate utcDate, LocalTime utcTime){

        LocalDateTime ldt = LocalDateTime.of(utcDate,utcTime);
        ZoneId zoneId = ZoneId.systemDefault();
        ZonedDateTime zonedt = ZonedDateTime.of(ldt,zoneId);
        System.out.println(zonedt.toLocalDate());
        System.out.println(zonedt.toLocalTime());
        System.out.println(zonedt.toLocalDate().toString() + " " + zonedt.toLocalTime().toString());


        return ldt;
    }

    /**
     * Returns local Date Time.
     * @param utcDate
     * @param utcTime
     * @return
     */
    public static LocalDateTime TimeZoneDT(LocalDate utcDate, LocalTime utcTime){


        LocalDateTime ldt = LocalDateTime.of(utcDate,utcTime);//local date time
        ZoneId zoneId = ZoneId.systemDefault();//System default name
        ZonedDateTime zonedt = ZonedDateTime.of(utcDate,utcTime,zoneId);
        System.out.println(zonedt.toLocalDate());
        System.out.println(zonedt.toLocalTime());
        System.out.println(zonedt.toLocalDate().toString() + " " + zonedt.toLocalTime().toString());


        return ldt;
    }


    /**
     * Returns app approval boolean.
     * @param unapprovedAppointmentDate
     * @param unapprovedAppointmentTime
     * @return
     */
    public static boolean estBusinessHoursApproval(LocalDate unapprovedAppointmentDate, LocalTime unapprovedAppointmentTime ){

        boolean appApproval = false;
        LocalDate currentDate = LocalDate.now();
        LocalTime currentTime = LocalTime.now();
        ZoneId zoneId = ZoneId.systemDefault();

        //Local Business Hours
        LocalTime bizStartTime = LocalTime.of(8,0);
        LocalTime bizEndTime = LocalTime.of(22,0);


        //Eastern Business Hours
        ZonedDateTime businessStart = ZonedDateTime.of(unapprovedAppointmentDate,bizStartTime,ZoneId.of("America/New_York"));//unapproved appointment date converted to est hours
        ZonedDateTime businessEnd = ZonedDateTime.of(unapprovedAppointmentDate,bizEndTime,ZoneId.of("America/New_York"));//unapproved appointment date converted to est hours

        //Local conversion of Business Hours
        ZonedDateTime ldtBusinessStart = businessStart.withZoneSameInstant(zoneId);
        ZonedDateTime ldtBusinessEnd = businessEnd.withZoneSameInstant(zoneId);


        //Convert Local Date Time unapproved appointment to Zone Date Time
          ZonedDateTime uAppointmentDate = ZonedDateTime.of(unapprovedAppointmentDate,unapprovedAppointmentTime,zoneId);


        //Convert Unapproved appointment Zone Date Time Object to EST for Comparison
        ZonedDateTime estUnapprovedAppointmentZDT = uAppointmentDate.withZoneSameInstant(ZoneId.of("America/New_York"));//Convert unapproved appointment ZDT Local to ZDT EST Hours



        //Compare unapproved appointment to business hours.
        if((estUnapprovedAppointmentZDT.getDayOfWeek().equals(DayOfWeek.SUNDAY) || estUnapprovedAppointmentZDT.getDayOfWeek().equals(DayOfWeek.SATURDAY))){
            appApproval = false;
//            System.out.println("approval on DOW: " + appApproval);
        }
        else if((estUnapprovedAppointmentZDT.isAfter(businessStart) && estUnapprovedAppointmentZDT.isBefore(businessEnd)) || (estUnapprovedAppointmentZDT.equals(businessStart) || estUnapprovedAppointmentZDT.equals(businessEnd))) {
            appApproval = true;
//            System.out.println("approval on Date Logic: " + appApproval);

        }



        return appApproval;

    }


    /**
     * Returns system error alert.
     * @param setAlertTitle
     * @param setContentAlert
     * @return
     */
    public static Alert systemAlert(String setAlertTitle ,String setContentAlert){
        Alert alert = new Alert(Alert.AlertType.ERROR);//Error Dialog Box
        alert.setTitle((setAlertTitle));
        alert.setContentText(setContentAlert);
        alert.showAndWait();
        alert.setResizable(true);
        return alert;
    }


    /**
     * Returns system confirmation alert.
     * @param setAlertTitle
     * @param setContentAlert
     * @return
     */
    public static Alert systemAlertConfirmation(String setAlertTitle ,String setContentAlert){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);//Error Dialog Box
        alert.setTitle((setAlertTitle));
        alert.setContentText(setContentAlert);
        alert.setResizable(true);

        return alert;
    }


    /**
     * Returns system information alert.
     * @param setAlertTitle
     * @param setContentAlert
     * @return
     */
    public static Alert systemAlertNotice(String setAlertTitle ,String setContentAlert){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);//Error Dialog Box
        alert.setTitle(setAlertTitle);
        alert.setContentText(setContentAlert);

        alert.setResizable(true);
        alert.setWidth(500);
        alert.setHeight(500);
        alert.showAndWait();
        return alert;
    }

    /**
     * Translate to french locality.
     */
    public static void frenchTranslation(){
        //language check
        Locale.setDefault(new Locale("fr"));

        Locale defaultLocale = Locale.getDefault();
        String defaultLanguage = defaultLocale.getLanguage();


        System.out.println("Default Locale:");
        System.out.println("Language: " + defaultLocale.getLanguage());
        System.out.println("Country: " + defaultLocale.getCountry());
        System.out.println("Variant: " + defaultLocale.getVariant());

        if(defaultLanguage.equals("fr")){



        }


    }














}
