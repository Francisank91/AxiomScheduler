package axiomscheduler.axiomscheduler.controller;

import axiomscheduler.axiomscheduler.dao.AnalyticsQuery;
import axiomscheduler.axiomscheduler.dao.AppointmentQuery;
import axiomscheduler.axiomscheduler.dao.ContactQuery;
import axiomscheduler.axiomscheduler.dao.CustomerQuery;
import axiomscheduler.axiomscheduler.model.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class AnalyticsController implements Initializable {
    public TableView<Reporting> custReportTableView;
    public TableColumn<Reporting,Integer> tapCustIdCol;
    public TableColumn<Reporting,String> tapCustNameCol;
    public TableColumn<Reporting,Integer> tapTotalAppointmentTimeCol;
    public TableView<Reporting> totalAppointmentTableView;
    public TableColumn<Reporting,String> taMonthCol;
    public TableColumn<Reporting,String> taTypeCol;
    public TableColumn<Reporting,Integer> taTotalAppCol;
    public TableView<Reporting> totalCustomersTableView;
    public TableColumn<Reporting,String> tcCountryCol;
    public TableColumn<Reporting,Integer> tcTotalCol;
    public Button mainViewBtn;
    public Button exitBtn;
    public TableView custReportTableViewReport;
    public TableColumn<Reporting,Integer> appointmentIdCol;
    public TableColumn<Reporting,String>  titleCol;
    public TableColumn<Reporting,String>  typeCol;
    public TableColumn<Reporting,String>  descriptionCol;
    public TableColumn<Reporting,Integer> startDtCol;
    public TableColumn<Reporting,Integer> endDtCol;
    public TableColumn<Reporting,Integer> appCustomerIdCol;
    public ComboBox contactFilterCB;


    @FXML
    private Label welcomeText;

    //Set Stage & Scene
    Stage stage;
    Parent scene;
    /**
     * Exits screen to main menu.
     * @param actionEvent
     */
    public void onActionMainViewBtn(ActionEvent actionEvent) throws IOException {
        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**
     * Exits application.
     * @param actionEvent
     */
    public void onActionExitBtn(ActionEvent actionEvent) {

        System.exit(0);


    }


    public void onActionContactFilterCB(ActionEvent actionEvent) {






    }







    /**
     * Initializes Analytics Controller View.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        String [] contactEmp = {"Anika Costa","Daniel Garcia","Li Lee"};
        contactFilterCB.getItems().addAll(contactEmp);

        //Table on Start
        ObservableList<Appointment> contactAppointmentsRL = AppointmentQuery.getAllAppointments();
        custReportTableViewReport.setItems(contactAppointmentsRL);

        //Listen Contact List
        contactFilterCB.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {


            @Override
            public void changed(ObservableValue observableValue, Object o, Object t1) {

                if (observableValue.getValue().equals("Anika Costa")) {// Code to execute if variable equals value1

                    ObservableList<Appointment> allContactAppointments = AppointmentQuery.getAllAppointments();
                    FilteredList<Appointment> filteredContactAppointments = new FilteredList<>(allContactAppointments, appointment -> appointment.getAppointmentContact().equals("Anika Costa"));
                    SortedList<Appointment> sortedContactAppointments = new SortedList<>(filteredContactAppointments);

                    custReportTableViewReport.setItems(sortedContactAppointments);
                    System.out.println(observableValue.getValue());
                    System.out.println("Anika Costa on");
                } else if (observableValue.getValue().equals("Daniel Garcia")) {// Code to execute if variable equals value2
                    ObservableList<Appointment> allContactAppointments = AppointmentQuery.getAllAppointments();
                    FilteredList<Appointment> filteredContactAppointments = new FilteredList<>(allContactAppointments, appointment -> appointment.getAppointmentContact().equals("Daniel Garcia"));
                    SortedList<Appointment> sortedContactAppointments = new SortedList<>(filteredContactAppointments);

                    custReportTableViewReport.setItems(sortedContactAppointments);
                    System.out.println(observableValue.getValue());
                    System.out.println("Daniel Garcia");
                } else if (observableValue.getValue().equals("Li Lee")) {// Code to execute if variable equals value2
                    ObservableList<Appointment> allContactAppointments = AppointmentQuery.getAllAppointments();
                    FilteredList<Appointment> filteredContactAppointments = new FilteredList<>(allContactAppointments, appointment -> appointment.getAppointmentContact().equals("Li Lee"));
                    SortedList<Appointment> sortedContactAppointments = new SortedList<>(filteredContactAppointments);

                    custReportTableViewReport.setItems(sortedContactAppointments);
                    System.out.println(observableValue.getValue());
                    System.out.println("Li Lee");
                } else {// Code to execute if variable doesn't match any case
                    custReportTableViewReport.refresh();
                    custReportTableViewReport.setItems(contactAppointmentsRL);
                    System.out.println(observableValue);
                }


            }
        });






        appointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("appointmentTitle"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("appointmentDescription"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        startDtCol.setCellValueFactory(new PropertyValueFactory<>("appointmentStartDt"));
        endDtCol.setCellValueFactory(new PropertyValueFactory<>("appointmentEndDt"));
        appCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentCustomerId"));








        custReportTableView.setItems(AnalyticsQuery.totalAppointmentsTimeReport());

        tapCustIdCol.setCellValueFactory(new PropertyValueFactory<>("tapCustomerId"));
        tapCustNameCol.setCellValueFactory(new PropertyValueFactory<>("tapCustomerName"));
        tapTotalAppointmentTimeCol.setCellValueFactory(new PropertyValueFactory<>("tapTotalAppointmentTime"));


        totalAppointmentTableView.setItems(AnalyticsQuery.totalAppointmentsReport());

        taMonthCol.setCellValueFactory(new PropertyValueFactory<>("taMonth"));
        taTypeCol.setCellValueFactory(new PropertyValueFactory<>("taType"));
        taTotalAppCol.setCellValueFactory(new PropertyValueFactory<>("totalAppointments"));



        totalCustomersTableView.setItems(AnalyticsQuery.totalCustomersReport());

        tcCountryCol.setCellValueFactory(new PropertyValueFactory<>("tcCountry"));
        tcTotalCol.setCellValueFactory(new PropertyValueFactory<>("totalCustomers"));



    }


}