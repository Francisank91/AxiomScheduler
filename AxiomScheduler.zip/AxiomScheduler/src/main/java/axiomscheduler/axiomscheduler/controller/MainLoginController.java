package axiomscheduler.axiomscheduler.controller;

import axiomscheduler.axiomscheduler.dao.AppointmentQuery;
import axiomscheduler.axiomscheduler.dao.UsersQuery;
import axiomscheduler.axiomscheduler.helper.utilities;
import axiomscheduler.axiomscheduler.model.GeneralInterface;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.TimeZone;

public class MainLoginController implements Initializable {
    public TextField usernameTxt;
    public TextField passwordTxt;
    public Button exitTxt;
    public Button loginBtn;
    public Label timeZonelbl;
    public Label usernameLbl;
    public Label passwordLbl;
    public Label axiomTitleLbl;
    public Label timezoneHeaderLbl;
    public int logAttempts = 0;

    GeneralInterface nullString = z -> z;
    @FXML
    private Label welcomeText;

    Stage stage;
    Parent scene;
    //Locale Resource Bundle

    ResourceBundle rb = ResourceBundle.getBundle("properties/Localization", Locale.getDefault());

    /**
     * Exits application.
     * @param event
     */
    @FXML
    public void onActionExitTxt(ActionEvent event) {

        System.exit(0);

    }


    /**
     * Validates access for user into the application and uses the LoggerValidation Lambda to pass null value for UserName logging.
     * @param actionEvent
     * @throws SQLException
     * @throws IOException
     */
    @FXML
    public void onActionLoginBtn(ActionEvent actionEvent) throws SQLException, IOException, InterruptedException {

        //
        int logValidation = 0;


        //retrieve values
        String userName = usernameTxt.getText();
        String userPassword = passwordTxt.getText();
        System.out.println(userName);
        System.out.println(userPassword);
        String loginValidation = UsersQuery.loginForm(userName, userPassword);


        //print file I/O creator
        String loginAttemptsFile = "src/main/java/axiomscheduler/axiomscheduler/_login_activity.txt", item;

        //Create File Writer Object - updater
        FileWriter loginWriter = new FileWriter(loginAttemptsFile, true);

        //Create and OpenFile
        PrintWriter outputFile = new PrintWriter(loginWriter);
        //Login File Logic

        //Null Lambda
        if(userName.isEmpty()){
          userName = nullString.stringReturn("null") ;
        }


            if (loginValidation.equals("true")) {
                logValidation = 1;

                logAttempts++;

                System.out.println("User Name:" + userName + " | Login attempt " + (logAttempts) + " | " + "Login Validation Successful on: | " + Instant.now().atZone(ZoneOffset.UTC) + "UTC");
                System.out.println();
                outputFile.println("User Name:" + userName + "Login attempt " + (logAttempts) + ": Login Validation Successful on: " + Instant.now().atZone(ZoneOffset.UTC) + "UTC");
            } else {
                logAttempts++;
                System.out.println(userName + " | Login attempt " + (logAttempts)  + " | " + ": Failed Login on: " + Instant.now().atZone(ZoneOffset.UTC) + "UTC");
                outputFile.println(userName + " | Login attempt " + (logAttempts) + " | " + ": Failed Login on: " + Instant.now().atZone(ZoneOffset.UTC) + "UTC");
                usernameTxt.clear();
                passwordTxt.clear();
            }

        //Close File
        outputFile.close();
        System.out.println("File has been written");


        //print file I/O creator


        //login door
        if (loginValidation.equals("true")) {

            //Cast&Link button to scene
            stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();//casting
            scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
            stage.setScene(new Scene(scene));
            stage.show();

            //Appointment Alert Query
            try {
                AppointmentQuery.appointmentAlert();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }


        } else {


            if (Locale.getDefault().getLanguage().equals("fr")) {
                utilities.systemAlert("Erreur de connexion", "Le nom d'utilisateur ET/OU le mot de passe n'est pas valide.\n Veuillez réessayer.");
                //System.out.println(rb.getString("Hello") + " " + rb.getString("World"));
            } else {
                utilities.systemAlert("Login Error", "Username AND/OR Password is invalid. Please try again.");

                System.out.println("failed login");
            }


        }



    }


    /**
     * Initializes resource bundle for language translation.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {




        //Display current system timezone
        ZoneId localZoneId = ZoneId.of(TimeZone.getDefault().getID());
        timeZonelbl.setText(String.valueOf(localZoneId));

        // French language check
//        Locale defaultLocale = Locale.getDefault();
//        String defaultLanguage = defaultLocale.getLanguage();


        // Locale.setDefault(new Locale("fr"));

        //Locale Resource Bundle
        ResourceBundle rb = ResourceBundle.getBundle("properties/Localization", Locale.getDefault());
        if(Locale.getDefault().getLanguage().equals("fr")){
            //timeZonelbl.setText(rb.getString("Exit"));
            usernameLbl.setText(rb.getString("Username"));
            passwordLbl.setText(rb.getString("Password"));
            axiomTitleLbl.setText(rb.getString("axiomTitle"));
            timezoneHeaderLbl.setText(rb.getString("timezoneTitle"));
            usernameTxt.setPromptText(rb.getString("username"));
            passwordTxt.setPromptText(rb.getString("password"));
            exitTxt.setText(rb.getString("Exit"));
            loginBtn.setText(rb.getString("Login"));
            //timeZonelbl.setText();




            System.out.println(rb.getString("loginErrorDescription") + " " + rb.getString("loginError"));
        }




    }
}