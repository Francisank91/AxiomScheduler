package axiomscheduler.axiomscheduler.controller;

import axiomscheduler.axiomscheduler.dao.CustomerQuery;
import axiomscheduler.axiomscheduler.dao.FirstLevelDivisionsQuery;
import axiomscheduler.axiomscheduler.model.Countries;
import axiomscheduler.axiomscheduler.model.Customer;
import axiomscheduler.axiomscheduler.model.Divisions;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import static java.lang.Integer.parseInt;

public class UpdateCustomerController implements Initializable {
    public TextField customerIdTxt;
    public TextField nameTxt;
    public TextField addressTxt;
    public TextField postalTxt;
    public ChoiceBox stateTerritoryCb;
    public ChoiceBox countryCb;
    public Button saveBtn;
    public Button cancelBtn;
    public TextField phoneNumberTxt;
    @FXML
    private Label welcomeText;

    //Set Stage & Scene
    Stage stage;
    Parent scene;

    /**
     * Retrieve customer details from Appointment View screen.
     * @param customer
     */
    public void sendCustomerDetails(Customer customer){
        //Pre-populate
        customerIdTxt.setText(String.valueOf(customer.getCustomerId()));
        nameTxt.setText(String.valueOf(customer.getCustomerName()));
        addressTxt.setText(String.valueOf(customer.getCustomerAddress()));
        phoneNumberTxt.setText(String.valueOf(customer.getCustomerPhone()));
        postalTxt.setText(String.valueOf(customer.getCustomerPostalCode()));
        stateTerritoryCb.setValue(String.valueOf(customer.getCustomerStateTerritory()));
        countryCb.setValue(String.valueOf(customer.getCustomerCountry()));



    }


    /**
     * Saves updated appointment.
     * @param actionEvent
     * @throws SQLException
     * @throws IOException
     */
    public void onActionSaveUpdate(ActionEvent actionEvent) throws SQLException, IOException {

        //retrieve values
        int customerId =parseInt(customerIdTxt.getText());
        String customerName = nameTxt.getText();
        String customerAddress = addressTxt.getText();
        String customerPostalCode = postalTxt.getText();
        String customerPhoneNumber = phoneNumberTxt.getText();
        //String customerCountry = countryCb.getValue().toString();
        String customerStateTerritory = stateTerritoryCb.getValue().toString();

        //Division Name to ID
        int divNameToID = FirstLevelDivisionsQuery.divisionNameToId(customerStateTerritory);

        //Add Customer
        CustomerQuery.updateCustomer(customerName, customerAddress, customerPhoneNumber, customerPostalCode, divNameToID, customerId);

        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Returns to Appointment View screen.
     * @param actionEvent
     * @throws IOException
     */
    public void onActionCancelUpdate(ActionEvent actionEvent) throws IOException {
        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Initializes Update Customer Controller View.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        customerIdTxt.setDisable(true);




        //Populate Country List
        countryCb.setItems(Countries.getCountryNames());
        //countryCb.setValue(Countries.getCountryNames().get(0));

        //Populate Country List
        countryCb.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observableValue, Object o, Object t1) {
                //ObservableList items = countryCb.getItems();
                if (observableValue.getValue().equals("U.S")) {// Code to execute if variable equals value1
                    stateTerritoryCb.setItems(Divisions.getDivisionOneNames());
                    System.out.println("US on");
                } else if (observableValue.getValue().equals("UK")) {// Code to execute if variable equals value2
                    stateTerritoryCb.setItems(Divisions.getDivisionTwoNames());
                    System.out.println("uk on");
                } else if (observableValue.getValue().equals("Canada")) {// Code to execute if variable equals value2
                    stateTerritoryCb.setItems(Divisions.getDivisionThreeNames());
                    System.out.println("Canada on");
                    // Add more cases as needed
                } else {// Code to execute if variable doesn't match any case
                    stateTerritoryCb.setItems(Countries.getCountries());
                    System.out.println(observableValue);
                }


            }
        });











    }
}