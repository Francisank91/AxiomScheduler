package axiomscheduler.axiomscheduler.controller;

import axiomscheduler.axiomscheduler.dao.AppointmentQuery;
import axiomscheduler.axiomscheduler.dao.CustomerQuery;
import axiomscheduler.axiomscheduler.dao.FirstLevelDivisionsQuery;
import axiomscheduler.axiomscheduler.helper.utilities;
import axiomscheduler.axiomscheduler.model.Appointment;
import axiomscheduler.axiomscheduler.model.Customer;
import axiomscheduler.axiomscheduler.model.Users;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.converter.LocalDateTimeStringConverter;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.chrono.ChronoLocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;


public class AppointmentViewController implements Initializable {
    public TableView<Appointment> appointmentsTableView;
    public TableColumn<Appointment, Integer> appointmentIdCol;
    public TableColumn<Appointment, String> titleCol;
    public TableColumn<Appointment, String> descriptionCol;
    public TableColumn<Appointment, String> locationCol;
    public TableColumn<Appointment, String> contactCol;
    public TableColumn<Appointment, String> typeCol;
    public TableColumn<Appointment, LocalDateTime> startDtCol;
    public TableColumn<Appointment, LocalDateTime> endDtCol;
    public TableColumn<Appointment, Integer> appCustomerIdCol;
    public TableColumn<Appointment, Integer> userIdCol;
    public ToggleGroup schedTG;
    public Button appointmentAddBtn;
    public Button appointmentUpdateBtn;
    public Button appointmentDeleteBtn;
    public TableView<Customer> customersTableView;
    public TableColumn<Customer, Integer> customerIdCol;
    public TableColumn<Customer, String> custNameCol;
    public TableColumn<Customer, String>  addressCol;
    public TableColumn<Customer, String>  stateTerritoryCol;
    public TableColumn<Customer, String> postalCol;
    public TableColumn<Customer, Integer> phoneCol;
    public Button customerAddBtn;
    public Button customerUpdateBtn;
    public Button customerDeleteBtn;
    public Button analyticsBtn;
    public Button exitBtn;
    public RadioButton allAppointmentsRB;
    public RadioButton weeklyAppointmentsRB;
    public RadioButton monthlyAppointmentsRB;
    @FXML
    private Label welcomeText;

    //Set Stage & Scene
    Stage stage;
    Parent scene;

    /**
     * Navigates to the Add Appointment screen.
     * @param actionEvent
     * @throws IOException
     */
    public void onActionAppointmentAddBtn(ActionEvent actionEvent) throws IOException {

        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AddAppointmentView.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**
     * Navigates to the Update Appointment screen.
     * @param actionEvent
     * @throws IOException
     */
    public void onActionAppointmentUpdateBtn(ActionEvent actionEvent) throws IOException {

        //Send Data Stream
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/UpdateAppointmentView.fxml"));
        loader.load();
        try {
            UpdateAppointmentController UAFController = loader.getController(); //calls controller methods
            UAFController.sendAppointmentDetails(appointmentsTableView.getSelectionModel().getSelectedItem());//Send data from selected
            System.out.println(appointmentsTableView.getSelectionModel().getSelectedItem());
            //Cast&Link button to scene
            stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();//casting
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene));
            stage.show();

        }catch (NullPointerException ex) {

            utilities.systemAlert("Error","No Appointment Selected");


        }


    }

    /**
     * Navigates to the Delete Appointment screen.
     * @param actionEvent
     * @throws SQLException
     * @throws IOException
     */
    public void onActionAppointmentDeleteBtn(ActionEvent actionEvent) throws SQLException, IOException {
        Alert alert1 = utilities.systemAlertConfirmation("Confirmation", "Are you sure you want to delete this Appointment?");
        Optional<ButtonType> result = alert1.showAndWait();


        boolean appointmentFound = false;


        try {





                //Appointment Delete
                if(result.isPresent() && result.get() == ButtonType.OK){
                    String appointmentNoticeId = String.valueOf(appointmentsTableView.getSelectionModel().getSelectedItem().getAppointmentId());
                    String appointmentNoticeType = String.valueOf(appointmentsTableView.getSelectionModel().getSelectedItem().getAppointmentType());
                    AppointmentQuery.deleteAppointment(appointmentsTableView.getSelectionModel().getSelectedItem().getAppointmentId());

                    //Cast&Link button to scene
                    stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
                    scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
                    stage.setScene(new Scene(scene));
                    stage.show();
                    utilities.systemAlertNotice("Notice", String.valueOf(new StringBuilder().append("Appointment ID: ").append(appointmentNoticeId + ", Type: " + appointmentNoticeType+ ", ").append(" has been deleted.")));

                }


        } catch (NullPointerException ex) {

            utilities.systemAlert("Error","No Appointment Selected");


        }




    }

    /**
     * Navigates to Add Customer screen.
     * @param actionEvent
     * @throws IOException
     */
    public void onActionCustomerAddBtn(ActionEvent actionEvent) throws IOException {

        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AddCustomerView.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();



    }

    /**
     * Navigates to the Customer Update screen.
     * @param actionEvent
     * @throws IOException
     */
    public void onActionCustomerUpdateBtn(ActionEvent actionEvent) throws IOException {

        //Send Data Stream
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/UpdateCustomerView.fxml"));
        loader.load();
        try {
            UpdateCustomerController UCFController = loader.getController(); //calls controller methods
            UCFController.sendCustomerDetails(customersTableView.getSelectionModel().getSelectedItem());//Send data from selected
            System.out.println(customersTableView.getSelectionModel().getSelectedItem());
            //Cast&Link button to scene
            stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();//casting
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene));
            stage.show();
        }catch (NullPointerException ex) {

            utilities.systemAlert("Error","No Customer Selected");


        }
    }

    /**
     * Navigates to the Customer Delete screen.
     * @param actionEvent
     * @throws SQLException
     * @throws IOException
     */
    public void onActionCustomerDeleteBtn(ActionEvent actionEvent) throws SQLException, IOException {
        Alert alert1 = utilities.systemAlertConfirmation("Confirmation", "Are you sure you want to delete this customer?");
        Optional<ButtonType> result = alert1.showAndWait();


        boolean customerAppFound = false;


        try {

            for(Appointment apt : AppointmentQuery.getAllAppointments()){
                if(customersTableView.getSelectionModel().getSelectedItem().getCustomerId() == apt.getAppointmentCustomerId()){
                    customerAppFound = true;
                    utilities.systemAlert("Error", "The selected customer's associated appointment needs to be deleted before deletion can occur.");
                    //Test
                    System.out.println("appointment found for: " + customersTableView.getSelectionModel().getSelectedItem().getCustomerId() + apt.getAppointmentCustomerId());
                    break;


                }else{
                    customerAppFound = false;

                }
            }


            if(customerAppFound == false){
                //Customer Delete
                if(result.isPresent() && result.get() == ButtonType.OK){
                    CustomerQuery.deleteCustomer(customersTableView.getSelectionModel().getSelectedItem().getCustomerId());

                    //Cast&Link button to scene
                    stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
                    scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
                    stage.setScene(new Scene(scene));
                    stage.show();
                    utilities.systemAlertNotice("Notice", "Customer has been deleted.");
                }

            }
        } catch (NullPointerException ex) {

            utilities.systemAlert("Error","No Customer Selected");


        }


    }

    /**
     * Navigates to the Axiom Reporting screen.
     * @param actionEvent
     * @throws IOException
     */
    public void onActionAnalyticsBtn(ActionEvent actionEvent) throws IOException {

        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AnalyticsView.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Exits application.
     * @param event
     */
    public void onActionExitBtn(ActionEvent event) {
        System.exit(0);
    }

    /**
     * Filters by all appointments
     * @param actionEvent
     */
    public void onActionAllAppointments(ActionEvent actionEvent) {

        appointmentsTableView.setItems(AppointmentQuery.getAllAppointments());

    }

    /**
     * Filters by weekly appointments
     * @param actionEvent
     */
    public void onActionWeeklyAppointments(ActionEvent actionEvent) {

        appointmentsTableView.setItems(AppointmentQuery.getAppointmentsByWeek());

    }

    /**
     * Filters by Monthly appointments
     * @param actionEvent
     */
    public void onActionMonthlyAppointments(ActionEvent actionEvent) {

        appointmentsTableView.setItems(AppointmentQuery.getAppointmentsByMonth());

    }


    /**
     * Initializes customer and appointment tables.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        appointmentsTableView.setItems(AppointmentQuery.getAllAppointments());


        appointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("appointmentTitle"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("appointmentDescription"));
        locationCol.setCellValueFactory(new PropertyValueFactory<>("appointmentLocation"));
        contactCol.setCellValueFactory(new PropertyValueFactory<>("appointmentContact"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        startDtCol.setCellValueFactory(new PropertyValueFactory<>("appointmentStartDt"));
        endDtCol.setCellValueFactory(new PropertyValueFactory<>("appointmentEndDt"));
        appCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentCustomerId"));
        userIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentUserId"));



        customersTableView.setItems(CustomerQuery.getAllCustomers());

        customerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        custNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        addressCol.setCellValueFactory(new PropertyValueFactory<>("customerAddress"));
        stateTerritoryCol.setCellValueFactory(new PropertyValueFactory<>("customerStateTerritory"));
        postalCol.setCellValueFactory(new PropertyValueFactory<>("customerPostalCode"));
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("customerPhone"));

        System.out.println(Customer.getCustomerIdList());
        System.out.println(Users.getUserIdList());




    }
}