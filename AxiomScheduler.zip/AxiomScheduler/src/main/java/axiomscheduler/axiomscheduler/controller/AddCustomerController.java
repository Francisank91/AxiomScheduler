package axiomscheduler.axiomscheduler.controller;

import axiomscheduler.axiomscheduler.dao.*;
import axiomscheduler.axiomscheduler.helper.utilities;
import axiomscheduler.axiomscheduler.model.Countries;
import axiomscheduler.axiomscheduler.model.Divisions;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.lang.invoke.SwitchPoint;
import java.net.URL;
import java.sql.Array;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class AddCustomerController implements Initializable {
    public TextField custIdTxt;
    public TextField nameTxt;
    public TextField addressTxt;
    public TextField postalTxt;
    public ChoiceBox stateTerritoryTxt;
    public ChoiceBox countryCb;
    public Button saveBtn;
    public Button cancelBtn;
    public TextField phoneNumberTxt;
    @FXML
    private Label welcomeText;

    //Set Stage & Scene
    Stage stage;
    Parent scene;

    FilteredList<Divisions> filteredDivisionsList = new FilteredList<>(FirstLevelDivisionsQuery.getAllDivisions(), i-> i.getDivision() != null);

    /**
     * Saves new Customer to database.
     * @param actionEvent
     * @throws SQLException
     * @throws IOException
     */
    public void onActionSaveBtn(ActionEvent actionEvent) throws SQLException, IOException {
        //retrieve values
        String appId = custIdTxt.getText();
        String customerName = nameTxt.getText();
        String customerAddress = addressTxt.getText();
        String customerPhoneNumber = phoneNumberTxt.getText();
        String customerPostalCode = postalTxt.getText();
        //String customerCountry = countryCb.getValue().toString();
        String customerStateTerritory = stateTerritoryTxt.getValue().toString();

        //Division Name to ID
        int divNameToID = FirstLevelDivisionsQuery.divisionNameToId(customerStateTerritory);

        //Add Customer
        CustomerQuery.addCustomer(customerName, customerAddress, customerPhoneNumber, customerPostalCode, divNameToID);

        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();

    }


    /**
     * Navigates user to Appointment View screen.
     * @param actionEvent
     * @throws IOException
     */
    public void onActionCancelBtn(ActionEvent actionEvent) throws IOException {
        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * Initializes Add Customer Controller View.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        //Disabled ID field
        custIdTxt.setDisable(true);
        custIdTxt.setPromptText("Auto Gen-Disabled");


        //Populate Country List
        countryCb.setItems(Countries.getCountryNames());
        //countryCb.setValue(Countries.getCountryNames().get(0));

        //Populate Country List
        countryCb.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observableValue, Object o, Object t1) {
               //ObservableList items = countryCb.getItems();
                if (observableValue.getValue().equals("U.S")) {// Code to execute if variable equals value1
                    stateTerritoryTxt.setItems(Divisions.getDivisionOneNames());
                    System.out.println("US on");
                } else if (observableValue.getValue().equals("UK")) {// Code to execute if variable equals value2
                    stateTerritoryTxt.setItems(Divisions.getDivisionTwoNames());
                    System.out.println("uk on");
                } else if (observableValue.getValue().equals("Canada")) {// Code to execute if variable equals value2
                    stateTerritoryTxt.setItems(Divisions.getDivisionThreeNames());
                    System.out.println("Canada on");
                    // Add more cases as needed
                } else {// Code to execute if variable doesn't match any case
                    stateTerritoryTxt.setItems(Countries.getCountries());
                    System.out.println(observableValue);
                }


            }
        });









    }
}