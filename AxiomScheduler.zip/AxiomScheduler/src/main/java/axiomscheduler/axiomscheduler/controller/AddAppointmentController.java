package axiomscheduler.axiomscheduler.controller;

import axiomscheduler.axiomscheduler.dao.AppointmentQuery;
import axiomscheduler.axiomscheduler.dao.ContactQuery;
import axiomscheduler.axiomscheduler.helper.utilities;
import axiomscheduler.axiomscheduler.model.Appointment;
import axiomscheduler.axiomscheduler.model.Customer;
import axiomscheduler.axiomscheduler.model.Users;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;


import static axiomscheduler.axiomscheduler.model.Appointment.getAppointmentCustomerIdList;
import static java.lang.Integer.parseInt;

public class AddAppointmentController implements Initializable {
    public TextField appIdTxt;
    public TextField titleTxt;
    public TextField descriptionTxt;
    public TextField locationTxt;
    public TextField TypeTxt;
    public DatePicker startDp;
    public DatePicker endDp;
    public ChoiceBox contactCb;
    public ChoiceBox startCb;
    public ChoiceBox endCb;
    public Button addAppSaveBtn;
    public Button addAppCancelBtn;
    public ComboBox customerIdCB;
    public ChoiceBox userIdCB;
    @FXML
    private Label welcomeText;

    //Set Stage & Scene
    Stage stage;
    Parent scene;

    /**
     * Adds new appointment to the database after validation.
     * @param actionEvent
     * @throws SQLException
     * @throws IOException
     */
    public void onActionaddAppSaveBtn(ActionEvent actionEvent) throws SQLException, IOException {
        //retrieve values
        String appId = appIdTxt.getText();
        String appTitle = titleTxt.getText();
        String appDescription = descriptionTxt.getText();
        String appLocation = locationTxt.getText();
        String appContact = contactCb.getValue().toString();
        String appType = TypeTxt.getText();
        LocalDate appStartDp = startDp.getValue();
        LocalDate appEndDP = endDp.getValue();
        LocalTime appStartTime = LocalTime.parse(startCb.getValue().toString());
        LocalTime appEndTime = LocalTime.parse(endCb.getValue().toString());
        int appCustId = parseInt(customerIdCB.getValue().toString());
        int appUserId = parseInt(userIdCB.getValue().toString());


        //Transform Contact
        int contactID = ContactQuery.contactNameToId(appContact);


        //Determine if appointment is within business hours
        boolean appointmentStartApproval = utilities.estBusinessHoursApproval(appStartDp,appStartTime);
        boolean appointmentEndApproval = utilities.estBusinessHoursApproval(appEndDP,appEndTime);

        //Transform Time
        LocalDateTime appointmentStart = utilities.TimeZone(appStartDp, appStartTime);
        LocalDateTime appointmentEnd = utilities.TimeZone(appEndDP, appEndTime);

        //Start & End contradictions
        boolean appError = false;
        LocalTime appointmentStartTime = appointmentStart.toLocalTime();
        LocalTime appointmentEndTime = appointmentEnd.toLocalTime();
        if (appointmentStart.getDayOfWeek().getValue() == appointmentEnd.getDayOfWeek().getValue() ) {
           //utilities.systemAlert("Error", "The start time cannot take place after the end time, please try again");
            System.out.println("//****** Start & End contradictions *********//");
            System.out.println("Appointment Start Day Get Value " + appointmentStart.getDayOfWeek().getValue());
            System.out.println("Appointment End Day Get Value " + appointmentEnd.getDayOfWeek().getValue());
            System.out.println("Same day true");
        } else if (!appointmentEnd.isBefore(appointmentStart)) {
            utilities.systemAlert("Error", "The appointment start and end time must take place on the same day, please try again");
            appError = true;
            System.out.println("//****** Start & End contradictions *********//");
            System.out.println("Appointment Start Day Get Value " + appointmentStart.getDayOfWeek().getValue());
            System.out.println("Appointment End Day Get Value " + appointmentEnd.getDayOfWeek().getValue());
            System.out.println("Appointment Start " + appointmentStart);
            System.out.println("Appointment End " + appointmentEnd);
            System.out.println("Appointment ! Value " + !appointmentEnd.isBefore(appointmentStart));
            System.out.println("Same Day 2");
        }
//        else if (!appointmentEnd.isBefore(appointmentStart)) {
//            utilities.systemAlert("Error", "The appointment start and end time must take place on the same day, please try again");
//            appError = true;
//            System.out.println("//****** Start & End contradictions *********//");
//            System.out.println("Appointment Start" + appointmentStart);
//            System.out.println("Appointment End" + appointmentStart);
//            System.out.println("Same Day 2");
//        }

       if (appointmentEndTime.isBefore(appointmentStartTime)) {


            utilities.systemAlert("Error", "The appointment start and end time must be in chronological order, please try again");
            appError = true;
            System.out.println("//****** Start & End contradictions *********//");
            System.out.println("Appointment Start " + appointmentStartTime);
            System.out.println("Appointment End " + appointmentEndTime);
            System.out.println("End Before Start");
        }
//       if (appointmentStartTime.isAfter(appointmentEndTime)) {
//
//
//            utilities.systemAlert("Error", "The appointment start and end time must be in chronological order, please try again");
//            appError = true;
//            System.out.println("//****** Start & End contradictions *********//");
//            System.out.println("Appointment Start " + appointmentStartTime);
//            System.out.println("Appointment End " + appointmentEndTime);
//            System.out.println("Start After End");
//        }

        //check time overlap
        int appOverlap = 0;
        ObservableList<Appointment> allappointments = AppointmentQuery.getAllAppointments();
        FilteredList<Appointment> filteredCustomerList = new FilteredList<>(AppointmentQuery.getAllAppointments(), i-> true);
        ArrayList<Appointment> customerAppointmentIdList = new ArrayList<>();
        for( Appointment i : filteredCustomerList){
            if(i.getAppointmentCustomerId() == appCustId){

                if(((appointmentStart.isAfter(i.getAppointmentStartDt()) || appointmentStart.equals(i.getAppointmentStartDt())) && (appointmentStart.isBefore(i.getAppointmentEndDt())))){
                    appOverlap = 1;

                }
                else if ((appointmentEnd.isAfter(i.getAppointmentStartDt())) && (appointmentEnd.isBefore(i.getAppointmentEndDt())) || appointmentEnd.equals(i.getAppointmentEndDt())) {
                    appOverlap = 2;
                }
                else if (((appointmentStart.isBefore(i.getAppointmentStartDt())) && (appointmentStart.isBefore(i.getAppointmentEndDt()))) && ((appointmentEnd.isAfter(i.getAppointmentStartDt())) && (appointmentEnd.isAfter(i.getAppointmentEndDt())))) {
                    appOverlap = 3;
                }
                else if (((appointmentStart.equals(i.getAppointmentStartDt()))) && ((appointmentEnd.equals(i.getAppointmentEndDt())))) {
                    appOverlap = 4;
                }
//                // customerAppointmentIdList.add(i);
//                System.out.println("//****** Overlap Diagnostic *********//");
//                System.out.println(appCustId);
//                System.out.println(i.getAppointmentCustomerId());
//                System.out.println(appointmentStart);
//                System.out.println(i.getAppointmentStartDt());
//                System.out.println(appointmentEnd);
//                System.out.println(i.getAppointmentEndDt());
            }


        }
        if(appOverlap > 0){
            utilities.systemAlert("Error", "The customer's appointment conflicts with an existing appointment , please try again");

        }
        System.out.println("appoverlap: " + appOverlap);


        //Save Appointment
        if((appointmentStartApproval == true) && (appointmentEndApproval == true) && (appError == false) && (appOverlap == 0)) {

            //Add Appointment
            AppointmentQuery.addAppointment( appTitle, appDescription, appLocation,appType,appointmentStart,appointmentEnd,appCustId,appUserId,contactID);

            System.out.println("Appointment Added");
            //Cast&Link button to scene
            stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
            scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
            stage.setScene(new Scene(scene));
            stage.show();
        }else if((appointmentStartApproval == false) || (appointmentEndApproval == false) && (appError == false) && (appOverlap == 0)){
            System.out.println("appointment Not added");
            utilities.systemAlert("Error","Appointment selected is outside the business hours of Monday - Friday 8:00 a.m. to 10:00 p.m. ET, please try again");
        }


//
//        //Diagnostic
//        System.out.println("//****** onActionaddAppSaveBtn Diagnostic *********//");
//        System.out.println("AppointmentStartApproval: " + appointmentStartApproval);
//        System.out.println("AppointmentStartApproval: " + appointmentEndApproval);
//        System.out.println("AppError: " + appError);
//        System.out.println("Start Time: " + appointmentStartTime);
//        System.out.println("End Time: " + appointmentEndTime);
//          System.out.println("App Overlap: " + appOverlap);


    }

    /**
     * Exits the Add Appointment screen to return to the main menu.
     * @param actionEvent
     * @throws IOException
     */
    public void onActionaddAppCancelBtn(ActionEvent actionEvent) throws IOException {


        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();




    }

    /**
     * Initializes Add Appointment view with the Start, End, and Contact combo boxes.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //Disabled ID field
        appIdTxt.setDisable(true);
        appIdTxt.setPromptText("Auto Gen-Disabled");



        //Contact ChoiceBox
        String [] contactEmp = {"Anika Costa","Daniel Garcia","Li Lee"};
        contactCb.getItems().addAll(contactEmp);



        //Start Time
        String [] startTime = {"00:00","00:15","00:30","00:45","01:00","01:15","01:30","01:45","02:00","02:15","02:30","02:45","03:00","03:15","03:30","03:45",
                "04:00","04:15","04:30","04:45","05:00","05:15","05:30","05:45","06:00","06:15","06:30","06:45","07:00","07:15","07:30","07:45",
                "08:00","08:15","08:30","08:45","09:00","09:15","09:30","09:45","10:00","10:15","10:30","10:45","11:00","11:15","11:30","11:45",
                "12:00","12:15","12:30","12:45","13:00","13:15","13:30","13:45","14:00","14:15","14:30","14:45","15:00","15:15","15:30","15:45",
                "16:00","16:15","16:30","16:45","17:00","17:15","17:30","17:45","18:00","18:15","18:30","18:45","19:00","19:15","19:30","19:45",
                "20:00","20:15","20:30","20:45","21:00","21:15","21:30","21:45","22:00","22:15","22:30","22:45","23:00","23:15","23:30","23:45"};
        startCb.getItems().addAll(startTime);

        //End Time
        String [] endTime = {"00:00","00:15","00:30","00:45","01:00","01:15","01:30","01:45","02:00","02:15","02:30","02:45","03:00","03:15","03:30","03:45",
                "04:00","04:15","04:30","04:45","05:00","05:15","05:30","05:45","06:00","06:15","06:30","06:45","07:00","07:15","07:30","07:45",
                "08:00","08:15","08:30","08:45","09:00","09:15","09:30","09:45","10:00","10:15","10:30","10:45","11:00","11:15","11:30","11:45",
                "12:00","12:15","12:30","12:45","13:00","13:15","13:30","13:45","14:00","14:15","14:30","14:45","15:00","15:15","15:30","15:45",
                "16:00","16:15","16:30","16:45","17:00","17:15","17:30","17:45","18:00","18:15","18:30","18:45","19:00","19:15","19:30","19:45",
                "20:00","20:15","20:30","20:45","21:00","21:15","21:30","21:45","22:00","22:15","22:30","22:45","23:00","23:15","23:30","23:45"};
        endCb.getItems().addAll(endTime);


        //Customer ComboBox
        customerIdCB.getItems().addAll(Customer.getCustomerIdList());

        //User ComboBox
        userIdCB.getItems().addAll(Users.getUserIdList());



    }
}