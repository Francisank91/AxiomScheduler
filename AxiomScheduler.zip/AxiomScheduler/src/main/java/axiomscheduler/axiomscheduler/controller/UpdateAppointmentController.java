package axiomscheduler.axiomscheduler.controller;

import axiomscheduler.axiomscheduler.dao.AppointmentQuery;
import axiomscheduler.axiomscheduler.dao.ContactQuery;
import axiomscheduler.axiomscheduler.dao.CustomerQuery;
import axiomscheduler.axiomscheduler.dao.FirstLevelDivisionsQuery;
import axiomscheduler.axiomscheduler.helper.utilities;
import axiomscheduler.axiomscheduler.model.Appointment;
import axiomscheduler.axiomscheduler.model.Customer;
import axiomscheduler.axiomscheduler.model.Users;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Year;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.ResourceBundle;

import static java.lang.Integer.parseInt;

public class UpdateAppointmentController implements Initializable {
    public TextField appIdTxt;
    public TextField titleTxt;
    public TextField descriptionTxt;
    public TextField locationTxt;
    public TextField typeTxt;

    public DatePicker startDateDP;
    public DatePicker endDateDP;
    public ChoiceBox contactCb;
    public ChoiceBox startTimeCb;
    public ChoiceBox endTimeCb;
    public Button saveBtn;
    public Button cancelTxt;
    public ComboBox customerIdCB;
    public ComboBox userIdCB;
    @FXML
    private Label welcomeText;

    //Set Stage & Scene
    Stage stage;
    Parent scene;

    /**
     * Provides Update Appointment screen with the selected appointment details from the View Appointment screen.
     * @param appointment
     */
    public void sendAppointmentDetails(Appointment appointment){
        //Pre-populate
        appIdTxt.setText(String.valueOf(appointment.getAppointmentId()));
        titleTxt.setText(String.valueOf(appointment.getAppointmentTitle()));
        descriptionTxt.setText(String.valueOf(appointment.getAppointmentDescription()));
        locationTxt.setText(String.valueOf(appointment.getAppointmentLocation()));
        typeTxt.setText(String.valueOf(appointment.getAppointmentType()));
        startDateDP.setValue(LocalDate.from(appointment.getAppointmentStartDt().toLocalDate()));
        endDateDP.setValue(LocalDate.from(appointment.getAppointmentEndDt().toLocalDate()));
        contactCb.setValue(String.valueOf(appointment.getAppointmentContact()));
        startTimeCb.setValue(LocalTime.from(appointment.getAppointmentStartDt().toLocalTime()));
        endTimeCb.setValue(LocalTime.from(appointment.getAppointmentEndDt().toLocalTime()));
        customerIdCB.setValue(String.valueOf(appointment.getAppointmentCustomerId()));
        userIdCB.setValue(String.valueOf(appointment.getAppointmentUserId()));



    }


    /**
     * Updates the selected appointment through a LAMBDA to select all appointments.
     * @param actionEvent
     * @throws IOException
     * @throws SQLException
     */
    public void onActionUpdateAppointment(ActionEvent actionEvent) throws IOException, SQLException {

        //retrieve values
        int appointmentId =parseInt(appIdTxt.getText());
        String appointmentTitle = titleTxt.getText();
        String appointmentDescription = descriptionTxt.getText();
        String appointmentLocation = locationTxt.getText();
        String appointmentContact = contactCb.getValue().toString();
        String appointmentType = typeTxt.getText();
        LocalDate appointmentStartDate = startDateDP.getValue();
        LocalDate appointmentEndDate = endDateDP.getValue();
        LocalTime appointmentStartTime = LocalTime.parse(startTimeCb.getValue().toString());
        LocalTime appointmentEndTime = LocalTime.parse(endTimeCb.getValue().toString());
        int appointmentCustomerId = parseInt(customerIdCB.getValue().toString());
        int appointmentUserId = parseInt(userIdCB.getValue().toString());


        //Transform Contact
        int appointmentContactId = ContactQuery.contactNameToId(appointmentContact);

        //Determine if appointment is within business hours
        boolean appointmentStartApproval = utilities.estBusinessHoursApproval(appointmentStartDate,appointmentStartTime);
        boolean appointmentEndApproval = utilities.estBusinessHoursApproval(appointmentEndDate,appointmentEndTime);

        //Transform Time
        LocalDateTime appointmentStartDT = utilities.TimeZone(appointmentStartDate,appointmentStartTime);
        LocalDateTime appointmentEndDT = utilities.TimeZone(appointmentEndDate,appointmentEndTime);



//        if(i.getAppointmentId() != appointmentCustomerId){
//
//        }else{
//
//
//
//
//
//
//
//        }



        //Start & End contradictions
        boolean appError = false;
        LocalTime updatedAppointmentStartTime = appointmentStartDT.toLocalTime();
        LocalTime updatedAppointmentEndTime = appointmentEndDT.toLocalTime();
        if (appointmentStartDT.getDayOfWeek().getValue() == appointmentEndDT.getDayOfWeek().getValue() ) {
            //utilities.systemAlert("Error", "The start time cannot take place after the end time, please try again");

            System.out.println("positive day");
        } else if (!appointmentEndDT.isBefore(appointmentStartDT)) {
            utilities.systemAlert("Error", "The appointment start and end time must take place on the same day, please try again");
            appError = true;
            System.out.println("false end");
        }
        else if (updatedAppointmentEndTime.isBefore(updatedAppointmentStartTime)) {


            utilities.systemAlert("Error", "The appointment start and end time must be in chronological order, please try again");
            appError = true;
            System.out.println("false end");
        }


        //check time overlap
        int appOverlap = 0;
        boolean updatedAppointmentConfirmed = false;
        ObservableList<Appointment> allAppointments = AppointmentQuery.getAllAppointments();
        FilteredList<Appointment> filteredCustomerList = new FilteredList<>(AppointmentQuery.getAllAppointments(), i-> true);
        ArrayList<Appointment> updatedAppointment = new ArrayList<>();

        for( Appointment i : allAppointments){
            if(((i.getAppointmentId() == appointmentId) && (i.getAppointmentCustomerId() == appointmentCustomerId))){
                appOverlap = -1;
                updatedAppointmentConfirmed = true;
                updatedAppointment.add(i);
                System.out.println("break activated");
                // customerAppointmentIdList.add(i);
                System.out.println("//****** Overlap Diagnostic *********//");
                System.out.println(appointmentCustomerId);
                System.out.println(i.getAppointmentCustomerId());
                System.out.println(appointmentStartDT);
                System.out.println(i.getAppointmentStartDt());
                System.out.println(appointmentEndDT);
                System.out.println(i.getAppointmentEndDt());
                System.out.println(appointmentId);
                System.out.println(i.getAppointmentId());
                System.out.println("appoverlap: " + appOverlap);
                break;

            }
        }//get updated record


        for( Appointment i : filteredCustomerList){
//            if(((i.getAppointmentId() == appointmentId) && (i.getAppointmentCustomerId() == appointmentCustomerId))){
//                appOverlap = -1;
//                updatedAppointmentConfirmed = true;
//                updatedAppointment.add(i);
//                System.out.println("break activated");
//                // customerAppointmentIdList.add(i);
//                System.out.println("//****** Overlap Diagnostic *********//");
//                System.out.println(appointmentCustomerId);
//                System.out.println(i.getAppointmentCustomerId());
//                System.out.println(appointmentStartDT);
//                System.out.println(i.getAppointmentStartDt());
//                System.out.println(appointmentEndDT);
//                System.out.println(i.getAppointmentEndDt());
//                System.out.println(appointmentId);
//                System.out.println(i.getAppointmentId());
//                System.out.println("appoverlap: " + appOverlap);
//                break;
//
//            }
            //updatedAppointment.get(0).getAppointmentId()
            //i.getAppointmentCustomerId() == appointmentCustomerId
            if(((updatedAppointment.get(0).getAppointmentId() != i.getAppointmentId()) && (updatedAppointment.get(0).getAppointmentCustomerId() == i.getAppointmentCustomerId()))){

                if(((appointmentStartDT.isAfter(i.getAppointmentStartDt()) || appointmentStartDT.equals(i.getAppointmentStartDt())) && (appointmentStartDT.isBefore(i.getAppointmentEndDt())))){
                    appOverlap = 1;
                    updatedAppointmentConfirmed = false;

                }
                else if ((appointmentEndDT.isAfter(i.getAppointmentStartDt())) && (appointmentEndDT.isBefore(i.getAppointmentEndDt())) || appointmentEndDT.equals(i.getAppointmentEndDt())) {
                    appOverlap = 2;
                    updatedAppointmentConfirmed = false;
                }
                else if (((appointmentStartDT.isBefore(i.getAppointmentStartDt())) && (appointmentStartDT.isBefore(i.getAppointmentEndDt()))) && ((appointmentEndDT.isAfter(i.getAppointmentStartDt())) && (appointmentEndDT.isAfter(i.getAppointmentEndDt())))) {
                    appOverlap = 3;
                    updatedAppointmentConfirmed = false;
                }
                else if (((appointmentStartDT.equals(i.getAppointmentStartDt()))) && ((appointmentEndDT.equals(i.getAppointmentEndDt())))) {
                    appOverlap = 4;
                    updatedAppointmentConfirmed = false;
                }
                // customerAppointmentIdList.add(i);
                System.out.println("//****** Overlap Diagnostic *********//");
                System.out.println(appointmentCustomerId);
                System.out.println(i.getAppointmentCustomerId());
                System.out.println(appointmentStartDT);
                System.out.println(i.getAppointmentStartDt());
                System.out.println(appointmentEndDT);
                System.out.println(i.getAppointmentEndDt());
                System.out.println(appointmentId);
                System.out.println(i.getAppointmentId());
                System.out.println("appoverlap: " + appOverlap);

//            }else if(((i.getAppointmentId() == appointmentId) && (i.getAppointmentCustomerId() == appointmentCustomerId))){
//                appOverlap = -1;
//                System.out.println("break activated");
//                // customerAppointmentIdList.add(i);
//                System.out.println("//****** Overlap Diagnostic *********//");
//                System.out.println(appointmentCustomerId);
//                System.out.println(i.getAppointmentCustomerId());
//                System.out.println(appointmentStartDT);
//                System.out.println(i.getAppointmentStartDt());
//                System.out.println(appointmentEndDT);
//                System.out.println(i.getAppointmentEndDt());
//                System.out.println(appointmentId);
//                System.out.println(i.getAppointmentId());
//                System.out.println("appoverlap: " + appOverlap);
//                break;
//
            }


        }
        if(appOverlap > 0){
            utilities.systemAlert("Error", "The customer's appointment conflicts with an existing appointment , please try again");
        }
        System.out.println("appoverlap Final: " + appOverlap);



        //Update Appointment
        //AppointmentQuery.updateAppointment(appointmentId, appointmentTitle, appointmentDescription, appointmentLocation, appointmentType, appointmentStartDT, appointmentEndDT, appointmentCustomerId, appointmentUserId, appointmentContactId);

        if(((appointmentStartApproval == true) && (appointmentEndApproval == true) && (appError == false) && (appOverlap < 0) && (updatedAppointmentConfirmed == true))) {

            //Update Appointment
            AppointmentQuery.updateAppointment(appointmentId, appointmentTitle, appointmentDescription, appointmentLocation, appointmentType, appointmentStartDT, appointmentEndDT, appointmentCustomerId, appointmentUserId, appointmentContactId);

            System.out.println("Appointment Added");
            //Cast&Link button to scene
            stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
            scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
            stage.setScene(new Scene(scene));
            stage.show();
        }else if(((appointmentStartApproval == false) || (appointmentEndApproval == false) && (appError == false) && (appOverlap < 0))){
            System.out.println("appointment Not added");
            utilities.systemAlert("Error","Appointment selected is outside the business hours of Monday - Friday 8:00 a.m. to 10:00 p.m. ET, please try again");
        }









    //Add exclusion for same appoinment_ID for being edited.

    }

    /**
     * Navigates user to Appointment View
     * @param actionEvent
     * @throws IOException
     */
    public void onActionCancelAppointmentUpdate(ActionEvent actionEvent) throws IOException {

        //Cast&Link button to scene
        stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();//casting
        scene = FXMLLoader.load((getClass().getResource("/view/AppointmentView.fxml")));
        stage.setScene(new Scene(scene));
        stage.show();

    }


    /**
     * Initializes Update Appointment Controller View.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //Disabled ID field
        appIdTxt.setDisable(true);
        appIdTxt.setPromptText("Auto Gen-Disabled");

        //Contact ChoiceBox
        String [] contactEmp = {"Anika Costa","Daniel Garcia","Li Lee"};
        contactCb.getItems().addAll(contactEmp);

        //Start Time
        String [] startTime = {"00:00","00:15","00:30","00:45","01:00","01:15","01:30","01:45","02:00","02:15","02:30","02:45","03:00","03:15","03:30","03:45",
                "04:00","04:15","04:30","04:45","05:00","05:15","05:30","05:45","06:00","06:15","06:30","06:45","07:00","07:15","07:30","07:45",
                "08:00","08:15","08:30","08:45","09:00","09:15","09:30","09:45","10:00","10:15","10:30","10:45","11:00","11:15","11:30","11:45",
                "12:00","12:15","12:30","12:45","13:00","13:15","13:30","13:45","14:00","14:15","14:30","14:45","15:00","15:15","15:30","15:45",
                "16:00","16:15","16:30","16:45","17:00","17:15","17:30","17:45","18:00","18:15","18:30","18:45","19:00","19:15","19:30","19:45",
                "20:00","20:15","20:30","20:45","21:00","21:15","21:30","21:45","22:00","22:15","22:30","22:45","23:00","23:15","23:30","23:45"};
        startTimeCb.getItems().addAll(startTime);

        //End Time
        String [] endTime = {"00:00","00:15","00:30","00:45","01:00","01:15","01:30","01:45","02:00","02:15","02:30","02:45","03:00","03:15","03:30","03:45",
                "04:00","04:15","04:30","04:45","05:00","05:15","05:30","05:45","06:00","06:15","06:30","06:45","07:00","07:15","07:30","07:45",
                "08:00","08:15","08:30","08:45","09:00","09:15","09:30","09:45","10:00","10:15","10:30","10:45","11:00","11:15","11:30","11:45",
                "12:00","12:15","12:30","12:45","13:00","13:15","13:30","13:45","14:00","14:15","14:30","14:45","15:00","15:15","15:30","15:45",
                "16:00","16:15","16:30","16:45","17:00","17:15","17:30","17:45","18:00","18:15","18:30","18:45","19:00","19:15","19:30","19:45",
                "20:00","20:15","20:30","20:45","21:00","21:15","21:30","21:45","22:00","22:15","22:30","22:45","23:00","23:15","23:30","23:45"};
        endTimeCb.getItems().addAll(endTime);


        //Customer ComboBox
        customerIdCB.getItems().addAll(Customer.getCustomerIdList());

        //User ComboBox
        userIdCB.getItems().addAll(Users.getUserIdList());


    }








}