package axiomscheduler.axiomscheduler.model;

import axiomscheduler.axiomscheduler.dao.AppointmentQuery;
import axiomscheduler.axiomscheduler.dao.CustomerQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 * This is the data model for customer appointments
 */






public class Appointment {
    private static ObservableList<Appointment> appointments = AppointmentQuery.getAllAppointments();
    private static ObservableList<Appointment> contactAppointments = AppointmentQuery.getAllAppointments();
    private int appointmentId;
    private String appointmentTitle;
    private String appointmentDescription;
    private String appointmentLocation;
    private String appointmentContact;
    private String appointmentType;
    public LocalDateTime appointmentStartDt;
    private LocalDateTime appointmentEndDt;
    private int appointmentCustomerId;
    private int appointmentUserId;


    public Appointment(int appointmentId, String appointmentTitle, String appointmentDescription, String appointmentLocation, String appointmentContact, String appointmentType, LocalDateTime appointmentStartDt, LocalDateTime appointmentEndDt, int appointmentCustomerId, int appointmentUserId) {
        this.appointmentId = appointmentId;
        this.appointmentTitle = appointmentTitle;
        this.appointmentDescription = appointmentDescription;
        this.appointmentLocation = appointmentLocation;
        this.appointmentContact = appointmentContact;
        this.appointmentType = appointmentType;
        this.appointmentStartDt = appointmentStartDt;
        this.appointmentEndDt = appointmentEndDt;
        this.appointmentCustomerId = appointmentCustomerId;
        this.appointmentUserId = appointmentUserId;
    }

    /**
     * Returns appointment ID
     * @return
     */
    public int getAppointmentId() {
        return appointmentId;
    }

    /**
     * Returns appointment Title
     * @return
     */
    public String getAppointmentTitle() {
        return appointmentTitle;
    }

    /**
     * Returns appointment Description
     * @return
     */
    public String getAppointmentDescription() {
        return appointmentDescription;
    }

    /**
     * Returns appointment Locaction
     * @return
     */
    public String getAppointmentLocation() {
        return appointmentLocation;
    }

    /**
     * Returns appointment Contact
     * @return
     */
    public String getAppointmentContact() {
        return appointmentContact;
    }

    /**
     * Returns appointment Type
     * @return
     */
    public String getAppointmentType() {
        return appointmentType;
    }

    /**
     * Returns appointment Start Date & Time
     * @return
     */
    public LocalDateTime getAppointmentStartDt() {
        return appointmentStartDt;
    }

    /**
     * Retunrs appoint End Date & Time
     * @return
     */
    public LocalDateTime getAppointmentEndDt() {
        return appointmentEndDt;
    }

    /**
     * Returns Customer ID associated with appointment
     * @return
     */
    public int getAppointmentCustomerId() {
        return appointmentCustomerId;
    }

    /**
     * Return User ID associated with appointment
     * @return
     */
    public int getAppointmentUserId() {
        return appointmentUserId;
    }


    /**
     * Returns Customer ID's from appointment list.
     * @return
     */
    public static ObservableList<Integer> getAppointmentCustomerIdList(){


        FilteredList<Appointment> filteredCustomerList = new FilteredList<>(appointments, i-> true);
        ArrayList<Integer> customerAppointmentIdList = new ArrayList<>();
        for( Appointment i : filteredCustomerList ){
            customerAppointmentIdList.add(i.getAppointmentCustomerId());
        }
        ObservableList<Integer> stringDivisionsList = FXCollections.observableArrayList(customerAppointmentIdList);

        return stringDivisionsList;
    }


    public static ObservableList<Appointment> getContactAppointments() {
        return contactAppointments;
    }

    public static void setContactAppointments(ObservableList<Appointment> contactAppointments) {
        Appointment.contactAppointments = contactAppointments;
    }
}
