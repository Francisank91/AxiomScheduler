package axiomscheduler.axiomscheduler.model;

import axiomscheduler.axiomscheduler.dao.FirstLevelDivisionsQuery;
import axiomscheduler.axiomscheduler.dao.UsersQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;

import java.util.ArrayList;
import java.util.function.IntUnaryOperator;

public class Users {

    private static ObservableList<Users> users = UsersQuery.getAllUsers();
    private int userId;

    private String userName;


    public Users(int userId, String userName) {
        this.userId = userId;
        this.userName = userName;
    }

    /**
     * Returns user ID.
     * @return
     */
    public int getUserId() {
        return userId;
    }

    /**
     * Returns User Name.
     * @return
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Returns user list.
     * @return
     */
    public static ObservableList<Users> getUsers() {
        return users;
    }

    /**
     * Sets user list.
     * @param users
     */
    public static void setUsers(ObservableList<Users> users) {
        Users.users = users;
    }

    /**
     * Returns User ID list.
     * @return
     */
    public static ObservableList<Integer> getUserIdList(){


        FilteredList<Users> filteredUserList = new FilteredList<>(users, i-> true);
        ArrayList<Integer> userIdList = new ArrayList<>();
        for( Users i : filteredUserList ){
            userIdList.add(i.getUserId());
        }
        ObservableList<Integer> intUserList = FXCollections.observableArrayList(userIdList);

        return intUserList;
    }














}
