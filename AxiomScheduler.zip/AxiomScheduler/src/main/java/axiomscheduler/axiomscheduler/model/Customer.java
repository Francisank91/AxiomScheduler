package axiomscheduler.axiomscheduler.model;

import axiomscheduler.axiomscheduler.dao.CustomerQuery;
import axiomscheduler.axiomscheduler.dao.FirstLevelDivisionsQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;

import java.util.ArrayList;

/**
 * This is the data model to our customers
 */
public class Customer {
    private static ObservableList<Customer> customers = CustomerQuery.getAllCustomers();
    private int customerId;
    private String customerName;
    private String customerAddress;
    private String customerStateTerritory;
    private String customerPostalCode;
    private String customerPhone;
    private String customerCountry;

    public Customer(int customerId, String customerName, String customerAddress, String customerStateTerritory, String customerPostalCode, String customerPhone, String customerCountry) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerStateTerritory = customerStateTerritory;
        this.customerPostalCode = customerPostalCode;
        this.customerPhone = customerPhone;
        this.customerCountry = customerCountry;
    }

    /**
     * Returns customer ID
     * @return
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * Returns customer Name
     * @return
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * Returns customer Address
     * @return
     */
    public String getCustomerAddress() {
        return customerAddress;
    }


    /**
     * Returns customer State or Territory
     * @return
     */
    public String getCustomerStateTerritory() {
        return customerStateTerritory;
    }

    /**
     * Returns customer Postal Code
     * @return
     */
    public String getCustomerPostalCode() {
        return customerPostalCode;
    }

    /**
     * Returns customer phone number
     * @return
     */
    public String getCustomerPhone() {
        return customerPhone;
    }

    /**
     * Returns customer country.
     * @return
     */
    public String getCustomerCountry() {
        return customerCountry;
    }

    /**
     * Returns customers.
     * @return
     */
    public static ObservableList<Customer> getCustomers() {
        return customers;
    }

    /**
     * Sets customer list.
     * @param customers
     */
    public static void setCustomers(ObservableList<Customer> customers) {
        Customer.customers = customers;
    }

    /**
     * Returns customer ID list.
     * @return
     */
    public static ObservableList<Integer> getCustomerIdList(){


        FilteredList<Customer> filteredCustomerList = new FilteredList<>(customers, i-> true);
        ArrayList<Integer> customerIdList = new ArrayList<>();
        for( Customer i : filteredCustomerList ){
            customerIdList.add(i.getCustomerId());
        }
        ObservableList<Integer> stringDivisionsList = FXCollections.observableArrayList(customerIdList);

        return stringDivisionsList;
    }









}
