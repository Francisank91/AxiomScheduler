package axiomscheduler.axiomscheduler.model;

public interface GeneralInterface {


        /**
         * Returns string z.
         * @param z
         * @return
         */
        String stringReturn(String z);


}
