package axiomscheduler.axiomscheduler.model;

import axiomscheduler.axiomscheduler.dao.CountryQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;

import java.util.ArrayList;

public class Countries {

    private static ObservableList<Countries> countries = CountryQuery.getAllCountries();

    private int country_ID;
    private String countryName;

    public Countries( int country_ID, String countryName) {
        this.country_ID = country_ID;
        this.countryName = countryName;
    }

    /**
     * Returns Country Name.
     * @return
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * Returns Country ID
     * @return
     */
    public int getCountry_ID() {
        return country_ID;
    }

    /**
     * Returns list of countries.
     * @return
     */
    public static ObservableList<Countries> getCountries() {
        return countries;
    }

    /**
     * Sets countries to observable list.
     * @param countries
     */
    public static void setCountries(ObservableList<Countries> countries) {
        Countries.countries = countries;
    }

    /**
     * Returns country names from countries table.
     * @return
     */
    public static ObservableList<String> getCountryNames(){


        FilteredList<Countries> filteredCountryList = new FilteredList<>(countries, i-> i.getCountryName() != null);
        ArrayList<String> countryList = new ArrayList<>();
        for( Countries i : filteredCountryList ){
            countryList.add(i.getCountryName());
        }
        ObservableList<String> stringCountryList = FXCollections.observableArrayList(countryList);

        return stringCountryList;
    }






}
