package axiomscheduler.axiomscheduler.model;

import axiomscheduler.axiomscheduler.dao.AnalyticsQuery;
import axiomscheduler.axiomscheduler.dao.AppointmentQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;

import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 * This is the data model for customer appointments
 */




public class Reporting {
    private static ObservableList<Reporting> totalAppointmentsReport = AnalyticsQuery.totalAppointmentsReport();
    private int totalAppointments;
    private String taMonth;
    private String taType;
    private int totalCustomers;
    private String tcCountry;
    private int tapCustomerId;
    private String tapCustomerName;
    private int tapTotalAppointmentTime;

    public Reporting(int totalAppointments, String taMonth, String taType) {
        this.totalAppointments = totalAppointments;
        this.taMonth = taMonth;
        this.taType = taType;
    }

    public Reporting(int totalCustomers, String tcCountry) {
        this.totalCustomers = totalCustomers;
        this.tcCountry = tcCountry;
    }



    public Reporting(int tapCustomerId, String tapCustomerName, int tapTotalAppointmentTime) {
        this.tapCustomerId = tapCustomerId;
        this.tapCustomerName = tapCustomerName;
        this.tapTotalAppointmentTime = tapTotalAppointmentTime;
    }

    /**
     * Returns Total Appointments Report.
     * @return
     */
    public int getTotalAppointments() {
        return totalAppointments;
    }

    /**
     * Returns reporting month.
     * @return
     */
    public String getTaMonth() {
        return taMonth;
    }

    /**
     * Returns reporting Type.
     * @return
     */
    public String getTaType() {
        return taType;
    }

    /**
     * Returns reporting Customers.
     * @return
     */
    public int getTotalCustomers() {
        return totalCustomers;
    }

    /**
     * Returns reporting Country
     * @return
     */
    public String getTcCountry() {
        return tcCountry;
    }

    /**
     * Returns reporting Customer ID.
     * @return
     */
    public int getTapCustomerId() {
        return tapCustomerId;
    }

    /**
     * Returns reporting sum of Appointment Time.
     * @return
     */
    public int getTapTotalAppointmentTime() {
        return tapTotalAppointmentTime;
    }

    /**
     * Returns reporting Customer Name.
     * @return
     */
    public String getTapCustomerName() {
        return tapCustomerName;
    }

    /**
     * Returns reporting Total Appointments Report.
     * @return
     */
    public static ObservableList<Reporting> getTotalAppointmentsReport() {
        return totalAppointmentsReport;
    }

    /**
     * Sets reporting Total Appointment Report.
     * @param totalAppointmentsReport
     */
    public static void setTotalAppointmentsReport(ObservableList<Reporting> totalAppointmentsReport) {
        Reporting.totalAppointmentsReport = totalAppointmentsReport;
    }
}
