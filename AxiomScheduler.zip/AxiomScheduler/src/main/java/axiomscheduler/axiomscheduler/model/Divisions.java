package axiomscheduler.axiomscheduler.model;

import axiomscheduler.axiomscheduler.dao.FirstLevelDivisionsQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;

import java.util.ArrayList;

public class Divisions {


    private static ObservableList<Divisions> divisions = FirstLevelDivisionsQuery.getAllDivisions();

    private String division;
    private int division_ID;
    private int country_ID;

    public Divisions(String division, int division_ID, int country_ID) {
        this.division = division;
        this.division_ID = division_ID;
        this.country_ID = country_ID;
    }

    /**
     * Returns Division Name
     * @return
     */
    public String getDivision() {
        return division;
    }

    /**
     * Returns Division ID.
     * @return
     */
    public int getDivision_ID() {
        return division_ID;
    }

    /**
     * Returns country IDs.
     * @return
     */
    public int getCountry_ID() {
        return country_ID;
    }

    /**
     * Returns Division list.
     * @return
     */
    public static ObservableList<Divisions> getDivisions() {
        return divisions;
    }

    /**
     * Sets Division list.
     * @param divisions
     */
    public static void setDivisions(ObservableList<Divisions> divisions) {
        Divisions.divisions = divisions;
    }

    /**
     * Returns Division Names.
     * @return
     */
    public static ObservableList<String> getDivisionNames(){


        FilteredList<Divisions> filteredDivisionsList = new FilteredList<>(divisions, i-> i.getDivision() != null);
        ArrayList<String> stateTerritory = new ArrayList<>();
        for( Divisions i : filteredDivisionsList ){
            stateTerritory.add(i.getDivision());
        }
        ObservableList<String> stringDivisionsList = FXCollections.observableArrayList(stateTerritory);

        return stringDivisionsList;
    }

    /**
     * Returns 1st Division Names.
     * @return
     */
    public static ObservableList<String> getDivisionOneNames(){


        ArrayList<String> firstDivisions = new ArrayList<>();


        for(Divisions i : divisions ){
            if(i.getCountry_ID() == 1){
                firstDivisions.add(i.getDivision());
            }
        }
        ObservableList<String> firstDivisionList = FXCollections.observableArrayList(firstDivisions);


        return firstDivisionList;
    }

    /**
     * Returns 2nd Division Names
     * @return
     */
    public static ObservableList<String> getDivisionTwoNames(){

        ArrayList<String> secondDivisions = new ArrayList<>();


        for(Divisions i : divisions ){
            if(i.getCountry_ID() == 2){
                secondDivisions.add(i.getDivision());
            }
        }
        ObservableList<String> secondDivisionList = FXCollections.observableArrayList(secondDivisions);


        return secondDivisionList;
    }

    /**
     * Returns 3rd Division Names.
     * @return
     */
    public static ObservableList<String> getDivisionThreeNames(){

        ArrayList<String> thirdDivisions = new ArrayList<>();


        for(Divisions i : divisions ){
            if(i.getCountry_ID() == 3){
                thirdDivisions.add(i.getDivision());
            }
        }
        ObservableList<String> thirdDivisionList = FXCollections.observableArrayList(thirdDivisions);


        return thirdDivisionList;
    }
}
