package axiomscheduler.axiomscheduler;

import axiomscheduler.axiomscheduler.dao.*;
import axiomscheduler.axiomscheduler.helper.utilities;
import axiomscheduler.axiomscheduler.model.Appointment;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.*;
import java.sql.SQLException;
import java.sql.Time;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;
import java.util.TimeZone;

import static axiomscheduler.axiomscheduler.model.Appointment.getAppointmentCustomerIdList;
import static java.util.TimeZone.setDefault;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/view/MainLogin.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
    public static void main(String[] args) throws SQLException, IOException {


        //Locale Test
        //Locale.setDefault(new Locale("fr"));
        //setDefault(TimeZone.getTimeZone("US/Pacific"));
        JDBC.openConnection();
        System.out.println(AnalyticsQuery.totalAppointmentsReport()); AnalyticsQuery.totalAppointmentsReport();


       launch();

        JDBC.closeConnection();


    }
}