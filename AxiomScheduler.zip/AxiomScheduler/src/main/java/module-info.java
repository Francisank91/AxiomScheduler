module axiomscheduler.axiomscheduler {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens axiomscheduler.axiomscheduler to javafx.fxml;
    exports axiomscheduler.axiomscheduler;
    exports axiomscheduler.axiomscheduler.controller;
    opens axiomscheduler.axiomscheduler.controller to javafx.fxml;

    opens axiomscheduler.axiomscheduler.model to javafx.fxml;
    exports axiomscheduler.axiomscheduler.model;


}